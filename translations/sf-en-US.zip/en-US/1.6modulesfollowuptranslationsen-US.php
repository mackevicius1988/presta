<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{followup}prestashop>followup_9c34e90380dac7b56fdd19192a99d531'] = 'Customer follow-up';
$_MODULE['<{followup}prestashop>followup_57476355fcd04050bff196ae9aa4673c'] = 'Follow-up with your customers with daily customized e-mails.';
$_MODULE['<{followup}prestashop>followup_f71a41841c80c2ef0ec02a6ad5449c65'] = 'Are you sure you want to delete all settings and your logs?';
$_MODULE['<{followup}prestashop>followup_e316b4398212d473f7f53c7728fe1c37'] = 'Settings updated succesfully';
$_MODULE['<{followup}prestashop>followup_003b06dcfe67596f17e3de26e6a436c8'] = 'Error occurred during settings update';
$_MODULE['<{followup}prestashop>followup_edf9feeab43a7623f6afc152d1ede515'] = 'Discount for your cancelled cart';
$_MODULE['<{followup}prestashop>followup_a053fc9952a7dfc79282eba56ab8ad3a'] = 'Thank you for your order.';
$_MODULE['<{followup}prestashop>followup_7fcd592dd47028c7c1f2d0ce9168a303'] = 'You are one of our best customers!';
$_MODULE['<{followup}prestashop>followup_c2ab23672d4bb31c7664bf8e854a10f7'] = 'We miss you!';
$_MODULE['<{followup}prestashop>followup_fba6524bb4f34a4c7d8e84b082fc4ce1'] = 'Define the settings and paste the following URL in the crontab, or call it manually on a daily basis:';
$_MODULE['<{followup}prestashop>followup_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Information';
$_MODULE['<{followup}prestashop>followup_87b1e57b5e8cd700618b6ae4938a4023'] = 'Four kinds of e-mail alerts are available in order to stay in touch with your customers!';
$_MODULE['<{followup}prestashop>followup_b547c073d144a57761d1d00d0b9d9f27'] = 'Cancelled carts';
$_MODULE['<{followup}prestashop>followup_ea9dc62a0ddf4640f019f04a22ab9835'] = 'For each cancelled cart (with no order), generate a discount and send it to the customer.';
$_MODULE['<{followup}prestashop>followup_2faec1f9f8cc7f8f40d521c4dd574f49'] = 'Enable';
$_MODULE['<{followup}prestashop>followup_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{followup}prestashop>followup_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{followup}prestashop>followup_b30690be173bcd4a83df0cd68f89a385'] = 'Discount amount';
$_MODULE['<{followup}prestashop>followup_2018945d252b94aeb99b0909f288717c'] = 'Discount validity';
$_MODULE['<{followup}prestashop>followup_225e75c29d32392d311f5dc94c792384'] = 'day(s)';
$_MODULE['<{followup}prestashop>followup_4c5caf3567f8b9ce900fe5973453b68c'] = 'The next process will send %d e-mail(s).';
$_MODULE['<{followup}prestashop>followup_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{followup}prestashop>followup_a8b8dbd070a92fb8b17baab71d8d633f'] = 'Re-order';
$_MODULE['<{followup}prestashop>followup_895858cf10b8a1750a42875cb9c69092'] = 'For each validated order, generate a discount and send it to the customer.';
$_MODULE['<{followup}prestashop>followup_f120254f109d626d73ddddeb9cda26e5'] = 'Next process will send: %d e-mail(s)';
$_MODULE['<{followup}prestashop>followup_8b83489bd116cb60e2f348e9c63cd7f6'] = 'Best customers';
$_MODULE['<{followup}prestashop>followup_a46ad892f7f00e051cc90050ff2e1ddf'] = 'For each customer raising a threshold, generate a discount and send it to the customer.';
$_MODULE['<{followup}prestashop>followup_2a63f555989152ba866b43a1faacd680'] = 'Threshold';
$_MODULE['<{followup}prestashop>followup_7d75b7b0f976b3091f490864c6ffbf97'] = 'Bad customers';
$_MODULE['<{followup}prestashop>followup_346f38f5b951daec00dcca38364f8359'] = 'For each customer who has already placed at least one order and with no orders since a given duration, generate a discount and send it to the customer.';
$_MODULE['<{followup}prestashop>followup_d82843c16839bfb05827d1912d89c917'] = 'Since x days';
$_MODULE['<{followup}prestashop>followup_0db377921f4ce762c62526131097968f'] = 'General';
$_MODULE['<{followup}prestashop>followup_1d52a8fe6cab6930fad9d814a1b0ca4c'] = 'Delete outdated discounts during each launch to clean database';
$_MODULE['<{followup}prestashop>stats_c33e404a441c6ba9648f88af3c68a1ca'] = 'Statistics';
$_MODULE['<{followup}prestashop>stats_dfc7d0b719158a75e0d324cc74f3185e'] = 'Detailed statistics for the last 30 days:';
$_MODULE['<{followup}prestashop>stats_d41455f28486975bfab163b66a473502'] = 'Sent = Number of sent e-mails';
$_MODULE['<{followup}prestashop>stats_4b416f06e3eea5059973acaa8325c8fa'] = 'Used = Number of discounts used (valid orders only)';
$_MODULE['<{followup}prestashop>stats_3c4d61c4fbde6177beb0f337711bde6c'] = 'Conversion % = Conversion rate';
$_MODULE['<{followup}prestashop>stats_44749712dbec183e983dcd78a7736c41'] = 'Date';
$_MODULE['<{followup}prestashop>stats_4a43635068b63d16d845f9feb6bcc125'] = 'Canceled carts';
$_MODULE['<{followup}prestashop>stats_c336ea796ae42ed04ed1ac310a678823'] = 'Re-orders';
$_MODULE['<{followup}prestashop>stats_8b83489bd116cb60e2f348e9c63cd7f6'] = 'Best customers';
$_MODULE['<{followup}prestashop>stats_7d75b7b0f976b3091f490864c6ffbf97'] = 'Bad customers';
$_MODULE['<{followup}prestashop>stats_7f8c0283f16925caed8e632086b81b9c'] = 'Sent';
$_MODULE['<{followup}prestashop>stats_019d1ca7d50cc54b995f60d456435e87'] = 'Used';
$_MODULE['<{followup}prestashop>stats_476d1393bbe84d62f25e2ce2ec3cd61c'] = 'Conversion (%)';
$_MODULE['<{followup}prestashop>stats_85b6769250887ba6c16099596c75164d'] = 'No statistics at this time.';


return $_MODULE;
