<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockbanner}prestashop>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Banner block';
$_MODULE['<{blockbanner}prestashop>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Displays a banner at the top of the shop.';
$_MODULE['<{blockbanner}prestashop>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'An error occurred while attempting to upload the file.';
$_MODULE['<{blockbanner}prestashop>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'The settings have been updated.';
$_MODULE['<{blockbanner}prestashop>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blockbanner}prestashop>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Top banner image';
$_MODULE['<{blockbanner}prestashop>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Upload an image for your top banner. The recommended dimensions are 1170 x 65px if you are using the default theme.';
$_MODULE['<{blockbanner}prestashop>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Banner Link';
$_MODULE['<{blockbanner}prestashop>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Enter the link associated to your banner. When clicking on the banner, the link opens in the same window. If no link is entered, it redirects to the homepage.';
$_MODULE['<{blockbanner}prestashop>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Banner description';
$_MODULE['<{blockbanner}prestashop>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Please enter a short but meaningful description for the banner.';
$_MODULE['<{blockbanner}prestashop>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockbanner}prestashop>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Choose a file';


return $_MODULE;
