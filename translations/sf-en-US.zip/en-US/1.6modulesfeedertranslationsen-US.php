<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{feeder}prestashop>feeder_4dce2f12546b229088d3cc214c3c2f7d'] = 'RSS products feed';
$_MODULE['<{feeder}prestashop>feeder_8e08defbab5b0cf81a6a6b8472b8feda'] = 'Generate a RSS feed for your latest products.';


return $_MODULE;
