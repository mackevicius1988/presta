<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_eaaf494f0c90a2707d768a9df605e94b'] = 'Payment logos block';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_3fd11fa0ede1bd0ace9b3fcdbf6a71c9'] = 'Adds a block which displays all of your payment logos.';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'The settings have been updated.';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'No CMS page is available.';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_829cb250498661a9f98a58dc670a9675'] = 'Destination page for the block\'s link';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_c9cc8cce247e49bae79f15173ce97354'] = 'Save';


return $_MODULE;
