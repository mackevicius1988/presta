<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{dashactivity}prestashop>dashactivity_0369e7f54bf8a30b2766e6a9a708de0b'] = 'Dashboard Activity';
$_MODULE['<{dashactivity}prestashop>dashactivity_02b5205ddff3073efc5c8b5b9cc165ba'] = '(from %s to %s)';
$_MODULE['<{dashactivity}prestashop>dashactivity_14542f5997c4a02d4276da364657f501'] = 'Direct link';
$_MODULE['<{dashactivity}prestashop>dashactivity_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{dashactivity}prestashop>dashactivity_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_MODULE['<{dashactivity}prestashop>dashactivity_914030b0a079e4eec3b3f5090c0fc35a'] = 'Active cart';
$_MODULE['<{dashactivity}prestashop>dashactivity_78fa968db0e87c6fc302614b26f93b5d'] = 'How long (in minutes) a cart is to be considered as active after the last recorded change (default: 30 min).';
$_MODULE['<{dashactivity}prestashop>dashactivity_47b8a33a5335cce8d4e353c4d1743f31'] = 'Online visitor';
$_MODULE['<{dashactivity}prestashop>dashactivity_b13a895857368f29e5e127767388b0ab'] = 'How long (in minutes) a visitor is to be considered as online after their last action (default: 30 min).';
$_MODULE['<{dashactivity}prestashop>dashactivity_6ad366c171531a83ffbc5625e159f340'] = 'Abandoned cart (min)';
$_MODULE['<{dashactivity}prestashop>dashactivity_8f1f252cfd3cbbcba7a2325f12e3dbc4'] = 'How long (in hours) after the last action a cart is to be considered as abandoned (default: 24 hrs).';
$_MODULE['<{dashactivity}prestashop>dashactivity_c760237f74bcc7e3f90ad956086edb66'] = 'hrs';
$_MODULE['<{dashactivity}prestashop>dashactivity_a5493eb7cba36f452249d093e7757adc'] = 'Abandoned cart (max)';
$_MODULE['<{dashactivity}prestashop>dashactivity_45e9c82415a3bee4413485c6bcb4347f'] = 'How long (in hours) after the last action a cart is no longer to be considered as abandoned (default: 24 hrs).';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_91b1b529580f2bb429493a51a1af932b'] = 'Activity overview';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_f1206f9fadc5ce41694f69129aecac26'] = 'Configure';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_63a6a88c066880c5ac42394a22803ca6'] = 'Refresh';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_254f642527b45bc260048e30704edb39'] = 'Configuration';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_edfc5fccc0439856b5bd432522ef47aa'] = 'Online Visitors';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_962b7da7912bc637b03626e23b5832b5'] = 'in the last %d minutes';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_7aaacf26dbf7d8929916618bb57d81f8'] = 'Active Shopping Carts';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_24042b0e4b783724dac4178df4db5d68'] = 'Currently Pending';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Orders';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_247d96cbab5bfc79dff10eb2ce6d8897'] = 'Return/Exchanges';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_54e85d70ea67acdcc86963b14d6223a8'] = 'Abandoned Carts';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_1c4407dd95b9ef941d30c2838208977e'] = 'Out of Stock Products';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_a274f4d4670213a9045ce258c6c56b80'] = 'Notifications';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_a644e8cd597f2b92aa52861632c0363d'] = 'New Messages';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_56d4e9a4c8e9f47549e8129393b3740f'] = 'Product Reviews';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_e539ae01694149c9e12295fe564a376b'] = 'Customers & Newsletters';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_8471314b4a53476fbf2379d9a0f7ac28'] = 'New Customers';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_d833d1b3c98b980090f79ad42badcf9f'] = 'New Subscriptions';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_e42bc03dcf18091455cb8a06ce1d56e9'] = 'Total Subscribers';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_e7935ae6c516d89405ec532359d2d75a'] = 'Traffic';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_1a4aeb4ca6cd736a4a7b25d8657d9972'] = 'Link to your Google Analytics account';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_d7e637a6e9ff116de2fa89551240a94d'] = 'Visits';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_945f170a18e4894c90381a3d01bdef8b'] = 'Unique Visitors';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_0fcff541ec15c6ed895d5dec49436488'] = 'Traffic Sources';


return $_MODULE;
