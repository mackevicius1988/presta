<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{newsletter}prestashop>newsletter_ffb7e666a70151215b4c55c6268d7d72'] = 'Newsletter';
$_MODULE['<{newsletter}prestashop>newsletter_804a924e464fd21ed92f820224c4091d'] = 'Generates a .CSV file for mass mailings';
$_MODULE['<{newsletter}prestashop>newsletter_c3987e4cac14a8456515f0d200da04ee'] = 'All countries';
$_MODULE['<{newsletter}prestashop>newsletter_fa01fd956e87307bce4c90a0de9b0437'] = 'Customers\' country';
$_MODULE['<{newsletter}prestashop>newsletter_7599b57d77ef1608b2f6da579794cc5b'] = 'Filter customers\' country.';
$_MODULE['<{newsletter}prestashop>newsletter_2198f293f5e1e95dddeff819fbca0975'] = 'Newsletter subscribers';
$_MODULE['<{newsletter}prestashop>newsletter_99006a61d48499231e1be92241cf772a'] = 'Filter newsletter subscribers.';
$_MODULE['<{newsletter}prestashop>newsletter_7e3a51a56ddd2846e21c33f05e0aea6f'] = 'All customers';
$_MODULE['<{newsletter}prestashop>newsletter_39f7a3e2b56e9bfd753ba6325533a127'] = 'Subscribers';
$_MODULE['<{newsletter}prestashop>newsletter_011d8c5d94f729f013963d856cd78745'] = 'Non-subscribers';
$_MODULE['<{newsletter}prestashop>newsletter_6395c19dc5a1cef9ca125b9736358dc7'] = 'Opt-in subscribers';
$_MODULE['<{newsletter}prestashop>newsletter_3136b84457870341f29f741f7a07d325'] = 'Filter opt-in subscribers.';
$_MODULE['<{newsletter}prestashop>newsletter_82e5e0bc0f9c776c98253d569c111c0f'] = 'No customers found with these filters!';
$_MODULE['<{newsletter}prestashop>newsletter_644ecc2486a059ca16b001a77909bf40'] = 'The .CSV file has been successfully exported: %d customers found.';
$_MODULE['<{newsletter}prestashop>newsletter_48e3d5f66961b621c78f709afcd7d437'] = 'Download the file';
$_MODULE['<{newsletter}prestashop>newsletter_dca37b874cf34bd5ebcf1c2fdc59a8b4'] = 'WARNING: When opening this .csv file with Excel, choose UTF-8 encoding to avoid strange characters.';
$_MODULE['<{newsletter}prestashop>newsletter_b40866b115d74009183e06fc86b5c014'] = '';
$_MODULE['<{newsletter}prestashop>newsletter_81573e0ea79138f02fd2cee94786d7e9'] = 'Error: cannot write';
$_MODULE['<{newsletter}prestashop>newsletter_73059f9530a1a37563150df4dea4bb70'] = 'All Subscribers';
$_MODULE['<{newsletter}prestashop>newsletter_a307579714b75082f3f8734971b125cd'] = 'Subscribers with account';
$_MODULE['<{newsletter}prestashop>newsletter_d0da5609e4aebc5d532de97511a5a34a'] = 'Subscribers without account';
$_MODULE['<{newsletter}prestashop>newsletter_4713ef5f2d6fc1e8f088c850e696a04b'] = 'Export customers';
$_MODULE['<{newsletter}prestashop>newsletter_dbb392a2dc9b38722e69f6032faea73e'] = 'Export .CSV file';


return $_MODULE;
