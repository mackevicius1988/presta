<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{eurovatgenerator}prestashop>eurovatgenerator_267e605d64e4f9568839936222896911'] = 'Europe VAT Generator';
$_MODULE['<{eurovatgenerator}prestashop>eurovatgenerator_d30c038f173012c8bdbed1be880e05a0'] = 'Easily get compliant with the new European VAT rules for virtual products.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_a73ab413109c43dd31f191a7d310e1ef'] = 'European VAT for virtual products';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_c2ef886abacc6606f222e8a12eeac91c'] = 'This module helps you to easily create the needed European taxes so that you can comply with the new rule on VAT for virtual products.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_47178f09d58b5d5c42576914ede0a423'] = 'Once done, you will have to amend your product catalog by assigning this European tax rule to the relevant virtual products.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_d234cb6833556b58cf492990ae9d704a'] = 'VAT per country';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_0f9f2ade08049f7b9300a6ef34949ed4'] = 'For each country, please indicate whether the normal VAT rate already exists on your shop. If not, it will be created automatically.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_29ed28e68b5c3365164aa2e0ccbe57bf'] = 'VAT already exists on my shop';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_b0fa79d5e3f6e671af3a8150f86ef60c'] = 'VAT does not exist - it will be created';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{eurovatgenerator}prestashop>configure_a73ab413109c43dd31f191a7d310e1ef'] = 'European VAT for virtual products';
$_MODULE['<{eurovatgenerator}prestashop>configure_c2ef886abacc6606f222e8a12eeac91c'] = 'This module helps you to easily create the needed European taxes so that you can comply with the new rule on VAT for virtual products.';
$_MODULE['<{eurovatgenerator}prestashop>configure_47178f09d58b5d5c42576914ede0a423'] = 'Once done, you will have to amend your product catalog by assigning this European tax rule to the relevant virtual products.';
$_MODULE['<{eurovatgenerator}prestashop>configure_d234cb6833556b58cf492990ae9d704a'] = 'VAT per country';
$_MODULE['<{eurovatgenerator}prestashop>configure_0f9f2ade08049f7b9300a6ef34949ed4'] = 'For each country, please indicate whether the normal VAT rate already exists on your shop. If not, it will be created automatically.';
$_MODULE['<{eurovatgenerator}prestashop>configure_29ed28e68b5c3365164aa2e0ccbe57bf'] = 'VAT already exists on my shop';
$_MODULE['<{eurovatgenerator}prestashop>configure_b0fa79d5e3f6e671af3a8150f86ef60c'] = 'VAT does not exist - it will be created';
$_MODULE['<{eurovatgenerator}prestashop>configure_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_7915b6921acab12d7737ea1810379b67'] = 'All the taxes have been created. A new tax rule “European VAT for virtual products” is now available.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_540fca2a5a01d285cd7509b98646cb14'] = 'What should I do now?';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_892faeb6b5c1a83d8a8fa51562129449'] = 'All the taxes have been created and gathered under a new tax rule “European VAT for virtual products”.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_e745e205828c0cddc2616ac37d06f35c'] = 'You now have to assign this new tax rule to the virtual products that are liable to be affected.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_2ef23860578d16db7a13ba8131362bba'] = 'You can also safely delete this module.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_05da7f6548358c48a37680f8c8845811'] = 'Go to Catalog';
$_MODULE['<{eurovatgenerator}prestashop>done_7915b6921acab12d7737ea1810379b67'] = 'All the taxes have been created. A new tax rule “European VAT for virtual products” is now available.';
$_MODULE['<{eurovatgenerator}prestashop>done_540fca2a5a01d285cd7509b98646cb14'] = 'What should I do now?';
$_MODULE['<{eurovatgenerator}prestashop>done_892faeb6b5c1a83d8a8fa51562129449'] = 'All the taxes have been created and gathered under a new tax rule “European VAT for virtual products”.';
$_MODULE['<{eurovatgenerator}prestashop>done_e745e205828c0cddc2616ac37d06f35c'] = 'You now have to assign this new tax rule to the virtual products that are liable to be affected.';
$_MODULE['<{eurovatgenerator}prestashop>done_2ef23860578d16db7a13ba8131362bba'] = 'You can also safely delete this module.';
$_MODULE['<{eurovatgenerator}prestashop>done_05da7f6548358c48a37680f8c8845811'] = 'Go to Catalog';


return $_MODULE;
