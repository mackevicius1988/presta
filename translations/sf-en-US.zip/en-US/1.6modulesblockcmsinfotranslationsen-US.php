<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Custom CMS information block';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Adds custom information blocks in your store.';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_666f6333e43c215212b916fef3d94af0'] = 'You must fill in all fields.';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_86432715902fbaf53de469fed3fa6c53'] = 'You have to select at least one shop.';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'An error occurred while attempting to save.';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'New custom CMS block';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Text';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Back to list';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_9d55fc80bbb875322aa67fd22fc98469'] = 'Shop association';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_6fcdef6ca2bb47a0cf61cd41ccf274f4'] = 'Block ID';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_9f82518d468b9fee614fcc92f76bb163'] = 'Shop';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_56425383198d22fc8bb296bcca26cecf'] = 'Block text';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Add new';


return $_MODULE;
