<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{socialsharing}prestashop>socialsharing_7dba9afe5ed3bbd1683c2c1a9e168cab'] = 'Social sharing';
$_MODULE['<{socialsharing}prestashop>socialsharing_622e2c510964bb1eb4e2e721ec6148c5'] = 'Displays social sharing buttons (Twitter, Facebook, Google+ and Pinterest) on every product page.';
$_MODULE['<{socialsharing}prestashop>socialsharing_c888438d14855d7d96a2724ee9c306bd'] = 'Settings updated';
$_MODULE['<{socialsharing}prestashop>socialsharing_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{socialsharing}prestashop>socialsharing_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{socialsharing}prestashop>socialsharing_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{socialsharing}prestashop>socialsharing_368140d2caf6b43106964fd615756d1b'] = 'Product comparison';
$_MODULE['<{socialsharing}prestashop>socialsharing_compare_6e55f5917f1f34501fc37388eb4b780d'] = 'Share this comparison with your friends:';
$_MODULE['<{socialsharing}prestashop>socialsharing_compare_3746d4aa96f19672260a424d76729dd1'] = 'Tweet';
$_MODULE['<{socialsharing}prestashop>socialsharing_compare_5a95a425f74314a96f13a2f136992178'] = 'Share';
$_MODULE['<{socialsharing}prestashop>socialsharing_compare_5b2c8bfd1bc974966209b7be1cb51a72'] = 'Google+';
$_MODULE['<{socialsharing}prestashop>socialsharing_compare_86709a608bd914b28221164e6680ebf7'] = 'Pinterest';
$_MODULE['<{socialsharing}prestashop>socialsharing_3746d4aa96f19672260a424d76729dd1'] = 'Tweet';
$_MODULE['<{socialsharing}prestashop>socialsharing_5a95a425f74314a96f13a2f136992178'] = 'Share';
$_MODULE['<{socialsharing}prestashop>socialsharing_5b2c8bfd1bc974966209b7be1cb51a72'] = 'Google+';
$_MODULE['<{socialsharing}prestashop>socialsharing_86709a608bd914b28221164e6680ebf7'] = 'Pinterest';


return $_MODULE;
