<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_1056d03db619b016d8fc6b60d08ef488'] = 'Product payment logos block';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_88fd6d994459806f2dcb8999ac03c76e'] = 'Displays the logos of the available payment systems on the product page.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_126b21ce46c39d12c24058791a236777'] = 'Invalid image';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_df7859ac16e724c9b1fba0a364503d72'] = 'An error occurred while attempting to upload the file.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_223795d3a336ef80c5b6a070ae4e0d2a'] = 'Block heading';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_c7dd01cfb61ff8c984c0aff44f6540e3'] = 'You can choose to add a heading above the logos.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_89ca5c48bbc6b7a648a5c1996767484c'] = 'Block image';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_9ce38727cff004a058021a6c7351a74a'] = 'Image link';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_826eeee52fe142372c3a2bc195eff911'] = 'You can either upload your own image using the form above, or link to it from the "Image link" option.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_c9cc8cce247e49bae79f15173ce97354'] = 'Save';


return $_MODULE;
