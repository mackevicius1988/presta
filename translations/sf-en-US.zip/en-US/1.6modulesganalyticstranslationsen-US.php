<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{ganalytics}prestashop>ganalytics_d86cf69a8b82547a94ca3f6a307cf9a6'] = 'Google Analytics';
$_MODULE['<{ganalytics}prestashop>ganalytics_135d2522825fa02688ab25a2e1c88c73'] = 'Gain clear insights into important metrics about your customers, using Google Analytics';
$_MODULE['<{ganalytics}prestashop>ganalytics_7ed5c154078e30b30b2f214299c5e9f5'] = 'Are you sure you want to uninstall Google Analytics? You will lose all the data related to this module.';
$_MODULE['<{ganalytics}prestashop>ganalytics_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{ganalytics}prestashop>ganalytics_630f6dc397fe74e52d5189e2c80f282b'] = 'Back to list';
$_MODULE['<{ganalytics}prestashop>ganalytics_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{ganalytics}prestashop>ganalytics_851bd83a102d143ee17d97f9e15e15af'] = 'Google Analytics Tracking ID';
$_MODULE['<{ganalytics}prestashop>ganalytics_ad8e83a47926dcb12e8a8fccd7fcf604'] = 'This information is available in your Google Analytics account';
$_MODULE['<{ganalytics}prestashop>ganalytics_bcd08e73ca9d8bfed2cccd50dd6d8328'] = 'Enable User ID tracking';
$_MODULE['<{ganalytics}prestashop>ganalytics_9bda6a2c3edca377eb901d7ea57c8b06'] = 'The User ID is set at the property level. To find a property, click Admin, then select an account and a property. From the Property column, click Tracking Info then User ID';
$_MODULE['<{ganalytics}prestashop>ganalytics_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{ganalytics}prestashop>ganalytics_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{ganalytics}prestashop>ganalytics_612e1a524ec979815b12182c34e2daa0'] = '';
$_MODULE['<{ganalytics}prestashop>ganalytics_8e7b67b44506b7ac6685da041a603044'] = 'Settings for User ID updated successfully';
$_MODULE['<{ganalytics}prestashop>configuration_1f13d86a35be758509f9bdfcce5ec55d'] = 'Your customers go everywhere; shouldn\'t your analytics.';
$_MODULE['<{ganalytics}prestashop>configuration_7063e771c3bb338ba74ac4e4716dbae1'] = 'Google Analytics shows you the full customer picture across ads and videos, websites and social tools, tables and smartphones. That makes it easier to serve your current customers and win new ones.';
$_MODULE['<{ganalytics}prestashop>configuration_df15c5cf264eb769b087f9d81aff029f'] = 'With ecommerce functionality in Google Analytics you can gain clear insight into important metrics about shopper behavior and conversion, including:';
$_MODULE['<{ganalytics}prestashop>configuration_613c191b4a1f82a454b72a840d96eefd'] = 'Product detail views';
$_MODULE['<{ganalytics}prestashop>configuration_d88b192dfe623e2a628a919b99fc1a4b'] = 'Internal merchandising Success';
$_MODULE['<{ganalytics}prestashop>configuration_ade6a18bb6c147db87bc9463240e455a'] = '"Add to cart" actions';
$_MODULE['<{ganalytics}prestashop>configuration_c975b6b93d71b19da73114c4adcedbda'] = 'The checkout process';
$_MODULE['<{ganalytics}prestashop>configuration_33f50b54625790316b86485ff3e794c4'] = 'Internal campaign clicks';
$_MODULE['<{ganalytics}prestashop>configuration_89c48ff165eedcc3cd1bd0007115669d'] = 'And purchase';
$_MODULE['<{ganalytics}prestashop>configuration_4632d86a96205013262bcfdd0279b39f'] = 'Merchants are able to understand how far along users get in the buying process and where they are dropping off.';
$_MODULE['<{ganalytics}prestashop>configuration_16fafb5cce24f766bf2c8fcebecf76fc'] = 'Create your account to get started.';
$_MODULE['<{ganalytics}prestashop>form-ps14_c9cc8cce247e49bae79f15173ce97354'] = 'Save';


return $_MODULE;
