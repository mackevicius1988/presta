<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_58ef962a87e6fbbea6027c17a954a18d'] = 'Įrašų nėra.';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_f5c493141bb4b2508c5938fd9353291a'] = 'Rodoma %1$s iš %2$s';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_49ee3087348e8d44e1feda1917443987'] = 'Pavadinimas';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_2a0440eec72540c5b30d9199c01f348c'] = 'Kiekis parduotas';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_ea067eb37801c5aab1a1c685eb97d601'] = 'Sumokėta viso';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_72fd9b5482201824daae557360d91196'] = 'Geriausi gamintojai';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_891374571b52a78a29a622308f1fa292'] = 'Prideda sąrašą geriausių gamintojų į statistikos skydelį.';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_998e4c5c80f27dec552e99dfed34889a'] = 'CSV eksportas';


return $_MODULE;
