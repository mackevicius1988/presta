<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statssales}prestashop>statssales_45c4b3e103155326596d6ccd2fea0f25'] = 'Pardavimai ir užsakymai';
$_MODULE['<{statssales}prestashop>statssales_d2fb07753354576172a2b144c373a610'] = 'Prideda grafikus, rodančius Statistikos skydeliui pardavimų ir užsakymų raidą.';
$_MODULE['<{statssales}prestashop>statssales_6602bbeb2956c035fb4cb5e844a4861b'] = 'Vedlys';
$_MODULE['<{statssales}prestashop>statssales_bdaa0cab56c2880f8f60e6a2cef40e63'] = 'Apie užsakymo būsenas';
$_MODULE['<{statssales}prestashop>statssales_fdfa8599f3887bef99e9572f3611260f'] = 'Administracinėje dalyje galite keisti šias užsakymo būsenas: Laukiama apmokėjimo čekiu, Apmokėjimas priimtas, Vyksta paruošimas, Išsiųsta, Pristatyta, Atšaukta, Grąžinimas, Apmokėjimo klaida, Išparduota ir Laukiamas mokėjimas bankiniu pavedimu.';
$_MODULE['<{statssales}prestashop>statssales_4b75384caa4e6830c22f15e06e0bfac0'] = 'Šios užsakymo būsenos negali būti pašalintos iš administracinės dalies: tačiau jūs turite galimybę pridėti daugiau būsenų.';
$_MODULE['<{statssales}prestashop>statssales_ddb21e1caa84c463bc744c412a7b05f5'] = 'Šie grafikai atvaizduoja jūsų parduotuvės užsakymų ir pardavimų apyvartos nustatytam laiko periodui raidą.';
$_MODULE['<{statssales}prestashop>statssales_ef9c3c65723819a9c183d857a39ff403'] = 'Jūs turėtumėt dažnai atsižvelgti į šį ekraną, nes jis jums leidžia greičiau kontroliuoti jūsų parduotuvės plėtrą. Jis jums leidžia kontroliuoti kelis laiko periodus.';
$_MODULE['<{statssales}prestashop>statssales_5cc6f5194e3ef633bcab4869d79eeefa'] = 'Grafike atvaizduojami tik galiojantys užsakymai.';
$_MODULE['<{statssales}prestashop>statssales_c3987e4cac14a8456515f0d200da04ee'] = 'Visos šalys';
$_MODULE['<{statssales}prestashop>statssales_d7778d0c64b6ba21494c97f77a66885a'] = 'Filtras';
$_MODULE['<{statssales}prestashop>statssales_9ccb8353e945f1389a9585e7f21b5a0d'] = 'Užsakymų atlikta:';
$_MODULE['<{statssales}prestashop>statssales_156e5c5872c9af24a5c982da07a883c2'] = 'Prekių nupirkta:';
$_MODULE['<{statssales}prestashop>statssales_998e4c5c80f27dec552e99dfed34889a'] = 'CSV eksportas';
$_MODULE['<{statssales}prestashop>statssales_ec3e48bb9aa902ba2ad608547fdcbfdc'] = 'Pardavimai:';
$_MODULE['<{statssales}prestashop>statssales_f6825178a5fef0a97dacf963409829f0'] = 'Jūs galite apačioje peržiūrėti užsakymų būsenų paskirstymą.';
$_MODULE['<{statssales}prestashop>statssales_da80af4de99df74dd59e665adf1fac8f'] = 'Nėra užsakymų šiam laiko tarpui.';
$_MODULE['<{statssales}prestashop>statssales_c58114720bcd52bfe96fd801cee77e93'] = 'Pateikti užsakymai';
$_MODULE['<{statssales}prestashop>statssales_c8be451a5698956a0e78b5c2caab4821'] = 'Nupirktos prekės';
$_MODULE['<{statssales}prestashop>statssales_b52b44c9d23e141b067d7e83b44bb556'] = 'Prekės:';
$_MODULE['<{statssales}prestashop>statssales_497a2a4cf0a780ff5b60a7a6e43ea533'] = 'Pardavimų valiuta: %s';
$_MODULE['<{statssales}prestashop>statssales_17833fb3783b26e0a9bc8b21ee85302a'] = 'Procentinis užsakymų pasiskirstymas pagal būseną.';


return $_MODULE;
