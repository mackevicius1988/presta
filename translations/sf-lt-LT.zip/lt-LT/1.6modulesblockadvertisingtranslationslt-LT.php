<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockadvertising}prestashop>blockadvertising_bedd646b07e65f588b06f275bd47be07'] = 'Skelbimų blokas';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_dc23a0e1424eda56d0700f7ebe628c78'] = 'Prideda reklamos bloką pasirinktoms el. parduotuvės puslapio dalims.';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_33476c93475bba83cdcaac18e09b95ec'] = 'Šis modulis turi būti prikabintas prie stulpelio, bet jusų tema nesuteikia tokios funkcijos';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_070e16b4f77b90e802f789b5be583cfa'] = 'Klaida įkeliant failą.';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_254f642527b45bc260048e30704edb39'] = 'Konfigūracija';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_a15e4232c6c1fc1e67816dd517e0e966'] = 'Paveikslėlis kitai reklamai';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_351ec5e81711303a312e244ec952f8e9'] = 'Pagal numatytuosius nustatymus, paveiksliukas atsiras kairiame stulpelyje. Rekomenduojami matmenys yra 155 x 163px.';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_4163f94824da4886254e88de13fbb863'] = 'Tikslinė (angl. target) nuoroda paveiksliukui';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_24c28ef67324898298e45026d8efabaf'] = 'Tikslinės (angl. target) nuorodos pavadinimas';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_78315dd2b27ef8037115b9f66351c155'] = 'Šis pavadinimas bus rodomas, kai jūs užvesite pelę ant reklamos bloko jūsų parduotuvėje.';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';


return $_MODULE;
