<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statscarrier}prestashop>statscarrier_2e6774abc54cb13cef2c5bfd5a2cb463'] = 'Kurjerių pasiskirstymas';
$_MODULE['<{statscarrier}prestashop>statscarrier_b56f2e8e5f8694e8d09cbd8ec27c4e57'] = 'Į statistikos skydelį prideda diagramą, kuri atvaizduoja kurjerių pasiskirstymą.';
$_MODULE['<{statscarrier}prestashop>statscarrier_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Visi';
$_MODULE['<{statscarrier}prestashop>statscarrier_d7778d0c64b6ba21494c97f77a66885a'] = 'Filtras';
$_MODULE['<{statscarrier}prestashop>statscarrier_ff61af405aa570a9000e6ba2da39857a'] = 'Ši diagrama rodo kurjerių pasiskirstymą Jūsų užsakymams. Jūs galite susiaurinti diagramą, kad atvaizduotumėte pasiskirstymą pagal tam tikrą užsakymo būseną.';
$_MODULE['<{statscarrier}prestashop>statscarrier_998e4c5c80f27dec552e99dfed34889a'] = 'CSV eksportas';
$_MODULE['<{statscarrier}prestashop>statscarrier_ae916988f1944283efa2968808a71287'] = 'Jokių užsakymų šiam periodui.';
$_MODULE['<{statscarrier}prestashop>statscarrier_d5b9d0daaf017332f1f8188ab2a3f802'] = 'Kurjerio užsakymų dalis.';


return $_MODULE;
