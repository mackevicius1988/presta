<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsorigin}prestashop>statsorigin_f0b1507c6bdcdefb60a0e6f9b89d4ae8'] = 'Lankytojo šaltinis';
$_MODULE['<{statsorigin}prestashop>statsorigin_a69c2a3091fe48c7f4f391595aa3ac19'] = 'Prideda diagramą į statistikos skydelį, kuri parodo, iš kokių puslapių atėjo lankytojai.';
$_MODULE['<{statsorigin}prestashop>statsorigin_14542f5997c4a02d4276da364657f501'] = 'Tiesioginė nuoroda';
$_MODULE['<{statsorigin}prestashop>statsorigin_3edf8ca26a1ec14dd6e91dd277ae1de6'] = 'Kilmės šalis';
$_MODULE['<{statsorigin}prestashop>statsorigin_4b69c1f7f555aa19fd90ee01e4aa63cd'] = 'Kortelėje nurodomos 10 populiariausių referencinių svetainių, kurios atvedė klientus į Jūsų parduotuvę.';
$_MODULE['<{statsorigin}prestashop>statsorigin_6602bbeb2956c035fb4cb5e844a4861b'] = 'Vedlys';
$_MODULE['<{statsorigin}prestashop>statsorigin_cec998cc46cd200fa97490137de2cc7f'] = 'Kas yra referencinė svetainė?';
$_MODULE['<{statsorigin}prestashop>statsorigin_54f00c2c9a36e2b300b5bacc1bb7912c'] = 'Referentas yra ankstesnės svetainės URL, kurioje buvusi nuoroda atvedė lankytoją.';
$_MODULE['<{statsorigin}prestashop>statsorigin_7231fe46fc79eb2b3a269f790b79e01f'] = 'Referentas taip pat leidžia Jums sužinoti, kokius raktažodžius paieškos sistemose naudoja lankytojai, naršydami Jūsų el. parduotuvėje.';
$_MODULE['<{statsorigin}prestashop>statsorigin_af19c8da1c414055c960a73d86471119'] = 'Referentu gali būti:';
$_MODULE['<{statsorigin}prestashop>statsorigin_c227be237c874ba6b2f8771d7b66b90e'] = 'Kažkas, kas įdėjo nuorodą į jūsų parduotuvę.';
$_MODULE['<{statsorigin}prestashop>statsorigin_ea87a2280d5cdb638a2727147a3dd85c'] = 'Partneris, su kuriuo keičiatės nuorodomis tam, kad pagerintumėt pardavimus arba pritrauktumėt naujus lankytojus.';
$_MODULE['<{statsorigin}prestashop>statsorigin_998e4c5c80f27dec552e99dfed34889a'] = 'CSV eksportas';
$_MODULE['<{statsorigin}prestashop>statsorigin_96b0141273eabab320119c467cdcaf17'] = 'Viso';
$_MODULE['<{statsorigin}prestashop>statsorigin_0bebf95ee829c33f34fde535ed4ed100'] = 'Tik tiesioginės nuorodos';
$_MODULE['<{statsorigin}prestashop>statsorigin_450a7e38e636dd49f5dfb356f96d3996'] = 'Pirmos 10 svetainių';
$_MODULE['<{statsorigin}prestashop>statsorigin_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Kiti';


return $_MODULE;
