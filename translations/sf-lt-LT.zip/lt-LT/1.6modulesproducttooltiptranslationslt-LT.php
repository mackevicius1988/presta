<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{producttooltip}prestashop>producttooltip_4776f7eb5998034f7bbc63b6457d1ff4'] = 'Prekių įrankių patarimai';
$_MODULE['<{producttooltip}prestashop>producttooltip_0406dc99f3d31535975fdddf6f4ae4d3'] = 'Parodo informaciją prekės puslapyje: kiek žmonių peržiūri prekę, kada paskutinį kartą buvo parduotas ir kada paskutinį kartą buvo įdėtas į krepšelį.';
$_MODULE['<{producttooltip}prestashop>producttooltip_c888438d14855d7d96a2724ee9c306bd'] = 'Nustatymai atnaujinti';
$_MODULE['<{producttooltip}prestashop>producttooltip_f4f70727dc34561dfde1a3c529b6205c'] = 'Nustatymai';
$_MODULE['<{producttooltip}prestashop>producttooltip_6a3f9bbed911bae4ffe5ab84294d7b9f'] = 'Lankytojų skaičius';
$_MODULE['<{producttooltip}prestashop>producttooltip_5c65d0f105e43f5186c1275fb83a661a'] = 'Rodo lankytojų skaičių, kurie šiuo metu žiūri šią prekę.';
$_MODULE['<{producttooltip}prestashop>producttooltip_6ce86506e83863b6414e760c8406e156'] = 'Jeigu aktyvuosite viršuje esančią funkciją, jūs turite aktyvuoti pirmąją, „Duomenų rinkimas statistikai“ (Statistikos Duomenys) modulio, funkciją („Išsaugoti puslapio peržiūras kiekvienam klientui“).';
$_MODULE['<{producttooltip}prestashop>producttooltip_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Įjungta';
$_MODULE['<{producttooltip}prestashop>producttooltip_b9f5c797ebbf55adccdd8539a65a0241'] = 'Išjungta';
$_MODULE['<{producttooltip}prestashop>producttooltip_18522b8438c82ae472267ff57e8db76f'] = 'Periodo trukmė';
$_MODULE['<{producttooltip}prestashop>producttooltip_3367d7aeafaae0cfdb8334d6e442a58f'] = 'Nustatyti lankytojų skaičiaus atvaizdavimo laikotarpio ilgį.';
$_MODULE['<{producttooltip}prestashop>producttooltip_946e06ba50194b981f04263795ed1433'] = 'Pavyzdžiui, jeigu nustatysite 30 minučių, modulis rodys lankytojų skaičių per paskutines 30 minučių.';
$_MODULE['<{producttooltip}prestashop>producttooltip_640fd0cc0ffa0316ae087652871f4486'] = 'minutės';
$_MODULE['<{producttooltip}prestashop>producttooltip_788b212e2524ec85463d68861342693c'] = 'Paskutinio užsakymo data';
$_MODULE['<{producttooltip}prestashop>producttooltip_43e5b083da426132daf3a9fe05362da3'] = 'Rodyti, kada paskutinį kartą prekė buvo užsakyta.';
$_MODULE['<{producttooltip}prestashop>producttooltip_f6916943428105792f433c337f4e9522'] = 'Pridėta į krepšelį';
$_MODULE['<{producttooltip}prestashop>producttooltip_3829b2b4ac783c8e53a25f5cd007224b'] = 'Jeigu prekė dar nebuvo užsakyta, rodyti kada paskutinį kartą ji buvo įdėta į krepšelį.';
$_MODULE['<{producttooltip}prestashop>producttooltip_7f2a0ec5efa8b7aaa2d814df0d18b722'] = 'Nerodyti įvykių, senesių nei';
$_MODULE['<{producttooltip}prestashop>producttooltip_44fdec47036f482b68b748f9d786801b'] = 'diena(-os)';
$_MODULE['<{producttooltip}prestashop>producttooltip_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{producttooltip}prestashop>producttooltip_265e0fd0901e35cae9978e2319b6c32e'] = '%d asmuo šiuo metu peržiūri šią prekę.';
$_MODULE['<{producttooltip}prestashop>producttooltip_858d0bcd440ff0d1cc1e6bd53d4fe9f6'] = '%d asmenys šiuo metu peržiūri šią prekę.';
$_MODULE['<{producttooltip}prestashop>producttooltip_b2ccdeedefb87a6f4c52b0926b030d65'] = 'Paskutinį kartą ši prekė buvo nupirkta: ';
$_MODULE['<{producttooltip}prestashop>producttooltip_f934c297c7d902f5871edb4a12acbb84'] = 'Paskutinį kartą ši prekė buvo įdėta į krepšelį: ';


return $_MODULE;
