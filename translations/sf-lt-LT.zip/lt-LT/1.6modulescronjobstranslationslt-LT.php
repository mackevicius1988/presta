<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{cronjobs}prestashop>cronjobsforms_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_d4169d52732e9ae8df56d2cbcad81a94'] = 'Užduoties aprašymas';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_70d4968bea9a6e76c0333904b9d385e4'] = 'Atnaujinti valiutas';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_0eff773cf33456a033e913f6ed18045c'] = 'Tikslinė (angl. target) nuoroda';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_07045abc579615634804f42bc0b2b4bb'] = 'Įveskite užduoties aprašymą.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_43773e69610c99be6c15daa4a2036443'] = 'Nurodykite periodinės (angl. cron) užduoties nuorodą.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_3a21e2309e8e6aa3759e466154508f2c'] = 'Nepamirškite naudoti absoliutų URL, kad jis galiotų! Nuoroda taip pat turi būti tokio pat domeno, kaip ir parduotuvė.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_be938fb8c5582085599dfa95368fb489'] = 'Užduoties dažnumas';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_b3364fad867d47ca61265fd315e4071e'] = 'Kokiu laiku turėtų būti vykdoma užduotis?';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_6c5d30049c4d8d644bd35650be4ac13a'] = 'Kurią mėnesio dieną turėtų būti įvykdyta užduotis?';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_a1457ee25ec20fa032d37509b5a90a4e'] = 'Kurį mėnesį turėtų būti įvykdyta užduotis?';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_65f768d204a3118f426c756056bef1e1'] = 'Kurią savaitės dieną turėtų būti įvykdyta užduotis?';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_f4f70727dc34561dfde1a3c529b6205c'] = 'Nustatymai';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_b3419e63398ccc41c062f36631bebd9a'] = 'Periodinės (angl. cron) užduoties režimas';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_972e73b7a882d0802a4e3a16946a2f94'] = 'Pagrindinis';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_eaf1dc6d93a18adb2619233d8e99c197'] = 'Naudokite PrestaShop periodinių (angl. cron) užduotčių web servisą, kad atliktumėte savo užduotis.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_9b6545e4cea9b4ad4979d41bb9170e2b'] = 'Išplėstinis';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_b6610b26530c9ee3d7bc4a478cf35299'] = 'Tik pažangiems vartotojams: naudokite savo periodinių (angl. cron) užduočių administratorių vietoj PrestaShop periodinių (angl. cron) užduočių serviso.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_2257d36bcb68362b24cf74f626bac599'] = 'Pažangus būdas leidžia Jums naudoti savo periodinių (angl. cron) užduočių administratorių vietoj PrestaShop periodinių (angl. cron) užduočių web serviso.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_94ad8b9f9d516489693dd835cf22bd3b'] = 'Pirmiausia įsitikinkite, ar "curl" biblioteka įdiegta Jūsų serveryje.';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_18028ef85b7ce8fbde749a2c49c6d18a'] = 'Norėdami vykdyti periodines (angl. cron) užduotis, įveskite šią eilutę į savo periodinių (angl. cron) užduočių administratorių:';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_b55e509c697e4cca0e1d160a7806698f'] = 'Valanda';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_03727ac48595a24daed975559c944a44'] = 'Diena';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_7cbb885aa1164b390a0bc050a64e1812'] = 'Mėnuo';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_e59278675b8f1e052b22b7e5e7d65da7'] = 'Savaitės diena';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_8cebfac3b4821cbc83041f5df54d7730'] = 'Paskutinis vykdymas';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_1e3208e0b0d5de9281f88c34169cda6b'] = 'Vienu šūviu';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Aktyvus';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_bdb6ae0d03e6793183349e00f67657f6'] = 'Modulis - Hukas';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_02fd27d2951d00b83f111f63611ea863'] = 'Kas valandą';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_48bf14c419a1d441412510faf39c326d'] = 'Kas dieną';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_8ed91b71d01993965915f3b296c20336'] = 'Kiekvieną mėnesį';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_50875e72e1477618055d1508112199b4'] = 'Kiekvieną savaitės dieną';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_6e7b34fa59e1bd229b207892956dc41c'] = 'Niekada';
$_MODULE['<{cronjobs}prestashop>cronjobsforms_16ed0a7b977ec3bbd23badfb5580d56f'] = 'Kiekvieną mėnesio dieną';
$_MODULE['<{cronjobs}prestashop>cronjobs_682ee2e41e510efdbced967430173c66'] = 'Periodinių (angl. cron) užduočių administratorius';
$_MODULE['<{cronjobs}prestashop>cronjobs_c75e110ddb05aea61563c50d7baf0ae0'] = 'Tvarko visas jūsų automatizuotas web užduotis iš vienos sąsajos.';
$_MODULE['<{cronjobs}prestashop>cronjobs_4093808c9781fb6ca2ed5ade71deff4d'] = 'Kad būtų galima naudoti šį modulį, aktyvuokite cURL (PHP plėtinį).';
$_MODULE['<{cronjobs}prestashop>cronjobs_035d5cdab2c65ad42b303f8125025160'] = 'Periodinės (angl. cron) užduotys';
$_MODULE['<{cronjobs}prestashop>cronjobs_6588952424b58b4c9fc9df026b668991'] = 'Pridėti naują užduotį';
$_MODULE['<{cronjobs}prestashop>form_ef7bd68a02b6b5656554f7a27d1c7bdf'] = 'Klaida!';
$_MODULE['<{cronjobs}prestashop>form_dc3fd488f03d423a04da27ce66274c1b'] = 'Įspėjimas!';
$_MODULE['<{cronjobs}prestashop>form_402e7a087747cb56c718bde84651f96a'] = 'Pavyko!';
$_MODULE['<{cronjobs}prestashop>configure_27c1f598c2b2b0a8e64424d257e8b398'] = 'Ką šis modulis daro?';
$_MODULE['<{cronjobs}prestashop>configure_c22203a97c7dd88dd68d1e864d46ee0c'] = 'CRON yra Unix sistemos įrankis, kuris suteikia laiku pagrįstą darbo planavimą: galite sukurti daug periodinių darbų, kurie vėliau bus automatiškai paleisti periodiškai nustatytu laiku, datomis ar intervalais.';
$_MODULE['<{cronjobs}prestashop>configure_d24ca73e026491b9610193f36d5edec8'] = 'Šis modulis jums suteikia cron įrankio funkcionalumą: jūs galite sukurti darbus, kurių metu bus iškviečiami jūsų įvesti saugūs URL į jūsų parduotuvę, tokiu būdų aktyvuojant atnaujinimo arba kitas automatizuotas užduotis.';
$_MODULE['<{cronjobs}prestashop>task_b43ff85c4fc17955aa3ba90827d65430'] = 'Nepamirškite naudoti absoliutų URL tikslinėje nuorodoje, kad jis galiotų! Nuoroda taip pat turi būti to paties domeno kaip ir parduotuvė.';


return $_MODULE;
