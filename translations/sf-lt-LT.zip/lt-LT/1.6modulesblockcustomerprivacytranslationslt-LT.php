<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_e0de5a06213f21c55ca3283c009e0907'] = 'Klientų duomenų privatumo blokas';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_f192f208f0bc97af4c5213eee3e78793'] = 'Prideda bloką, rodantį žinutę apie kliento privatumo duomenis.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Konfigūracija atnaujinta';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Sutikite su vartojo informacijos privatumu pažymėdami varnelę žemiau.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_f4f70727dc34561dfde1a3c529b6205c'] = 'Nustatymai';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_9a730b88a32c2932d18b8b6043cc4fb7'] = 'Rodyti paskyros kūrimo formoje';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Įjungta';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b9f5c797ebbf55adccdd8539a65a0241'] = 'Išjungta';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_88997f015a0ee407a5e797011ddd090d'] = 'Klientų duomenų privatumo pranešimas paskyros kūrimo formoje:';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'Duomenų privatumo informacija kuri bus rodoma paskyros sukūrimo formoje.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b51d73fb490ad1245fa9b87042bbbbb7'] = 'Patarimas: jeigu kliento privatumo žinutė yra per ilga, kad būtų rašoma formoje, jūs galite pridėti nuorodą į vieną iš savo puslapių. Tai gali būti lengvai sukurta per „TVS“ puslapį po „Nustatymai“ meniu.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_67ebed7cf9667003ad2047609440513a'] = 'Rodyti kliento srityje';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fc67768369eadd8d4fb1e7839f5eae69'] = 'Klientų duomenų privatumo pranešimas kliento srityje:';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_432d64c20d5d06378d96c247c3f358f4'] = 'Kliento duomenų privatumo pranešimas bus rodomas "Asmeninė informacija" puslapyje, kliento srityje.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_de1126ae0ac67eb4fda28cfad8429c79'] = 'Patarimas: jeigu kliento privatumo žinutė yra per ilga, kad būtų rašoma tiesiai puslapyje, jūs galite pridėti nuorodą į vieną iš savo puslapių. Jūs galite lengvai sukurti „TVS“ puslapį „Nustatymai“ meniu punkte.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Vartotojo informacijos privatumas';


return $_MODULE;
