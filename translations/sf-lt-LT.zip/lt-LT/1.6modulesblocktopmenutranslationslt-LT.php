<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_e5b7525b4214a759876af4448bd6b87d'] = 'Viršutinis horizontalus meniu';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_f7979d86fe0b2cd11f44747ed4ff1100'] = 'Prideda horizontalų meniu puslapio viršuje.';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_efc226b17e0532afff43be870bff0de7'] = 'Nustatymai atnaujinti.';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_d9a776c185f73d018b2915f4d5e7cc05'] = 'Nepavyko atnaujinti nustatymų šiai parduotuvei(-ėms): %s';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_f32880ae5183a02c0a743bfd37a42cbc'] = 'Užpildykite "nuorodos" lauką.';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_cf8d684bd5f89d30da67c95363a48ab9'] = 'Pridėkite žymą.';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_e8d6809226ab177013e0a26bd2d8b60d'] = 'Pridėkite žymą numatytajai kalbai.';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_3da9d5745155a430aac6d7de3b6de0c8'] = 'Nuoroda pridėta.';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_022bb0995e3256abeeac1788a5e2c5b3'] = 'Nepavyko pridėti nuorodos šiai parduotuvei(-ėms): %s';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_e24e88b590807c2816be15abd7c7dbbc'] = 'Nuoroda pašalinta.';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_e418ee8626f7941239c5b7a0880691ae'] = 'Nepavyko ištrinti nuorodos šiai parduotuvei(-ėms): %s';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_beb4f951c292ec9218473ffe5f59849d'] = 'Nuoroda paredaguota.';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_b1a23c1a76918c10acc27bfa60798c42'] = 'Negalite valdyti viršutinio meniu "Visos parduotuvės" ar "Parduotuvių grupė" kontekste, konkrečiai pasirinkite parduotuvę, kurią norite redaguoti';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_298b615220606d42b6ac60269df0d321'] = 'Pakeitimai bus pritaikyti parduotuvei: %s';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_aef3662e6419ddaaa0a31df70e3b6557'] = 'Pakeitimai bus pritaikyti šiai grupei: %s';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_dd25f68471362f6f5f183d6158d67854'] = 'Pakeitimai bus pritaikyti visoms parduotuvėms';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_bf24faeb13210b5a703f3ccef792b000'] = 'Visi gamintojai';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_ecf253735ac0cba84a9d2eeff1f1b87c'] = 'Visi tiekėjai';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_944d19a34e5fa333a6a0de27e8c971da'] = 'Pagrindinio meniu nuorodos';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_eacd852cc1f621763dccbda3f3c15081'] = 'Paieškos laukelis';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Įjungta';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_b9f5c797ebbf55adccdd8539a65a0241'] = 'Išjungta';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_0a112e5da975d8eaf28df9219c397764'] = 'Visi aktyvių prekių derinių kiekiai bus pakeisti';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_1a6191a2dc928ff8fb8c02c050975ea7'] = 'Atnaujinti nuorodą';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_58e9b25bb2e2699986a3abe2c92fc82e'] = 'Pridėti naują nuorodą';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_b021df6aac4654c454f46c77646e745f'] = 'Žyma';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Nuoroda';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_e5dc8e5afea0a065948622039358de37'] = 'Naujas langas';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_ec211f7c20af43e742bf2570c3cb84f9'] = 'Pridėti';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_06933067aafd48425d67bcb01bba5cb6'] = 'Atnaujinimas';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_c7da501f54544eba6787960200d9efdb'] = 'TVS';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_ec136b444eede3bc85639fac0dd06229'] = 'Tiekėjas';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_c0bd7654d5b278e65f21cf4e9153fdb4'] = 'Gamintojas';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_af1b98adf7f686b84cd0b443e022b7a0'] = 'Kategorijos';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_12a521af593422cd508f7707662c9eb2'] = 'Parduotuvės';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_068f80c7519d0528fb08e82137a72131'] = 'Prekės';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_778118c7dd993db08f704e15efa4a7fa'] = 'Pasirinkite prekės ID';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_56e8bf6c54f1638e7bce5a2fcd5b20fe'] = 'Pagrindinio meniu nuorodos';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_449f6d82cde894eafd3c85b6fa918f89'] = 'Nuorodos ID';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_e93c33bd1341ab74195430daeb63db13'] = 'Parduotuvės pavadinimas';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_387a8014f530f080bf2f3be723f8c164'] = 'Nuorodų sąrašas';
$_MODULE['<{blocktopmenu}prestashop>form_17a1352d3f69a733fd472fce0238a07d'] = 'Nurodykite prekės ID';
$_MODULE['<{blocktopmenu}prestashop>form_6bb999afde6fca60d70edce79d20b370'] = 'Prekės ID #';
$_MODULE['<{blocktopmenu}prestashop>form_3ee3549ff0c93372a730749f784e9438'] = 'Pasirinkite tik vieną elementą';
$_MODULE['<{blocktopmenu}prestashop>form_e1b11c03820641dd1d1441bf68898d08'] = 'Pakeisti poziciją';
$_MODULE['<{blocktopmenu}prestashop>form_3713a99a6284e39061bd48069807aa52'] = 'Parinkti elementai';
$_MODULE['<{blocktopmenu}prestashop>form_8fb31b552d63ffef9df733646a195bc0'] = 'Esantys elementai';
$_MODULE['<{blocktopmenu}prestashop>form_1063e38cb53d94d386f21227fcd84717'] = 'Pašalinti';
$_MODULE['<{blocktopmenu}prestashop>form_ec211f7c20af43e742bf2570c3cb84f9'] = 'Pridėti';
$_MODULE['<{blocktopmenu}prestashop>blocktopmenu_b61541208db7fa7dba42c85224405911'] = 'Meniu';


return $_MODULE;
