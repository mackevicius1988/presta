<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{dashgoals}prestashop>dashgoals_50698c5b8ffaf2b7dd089898a244a668'] = 'Skydelis Tikslai';
$_MODULE['<{dashgoals}prestashop>dashgoals_14089da5dd6132b674d9829b136efff9'] = 'Prideda bloką su jūsų parduotuvės prognoze.';
$_MODULE['<{dashgoals}prestashop>dashgoals_86f5978d9b80124f509bdb71786e929e'] = 'Sausis';
$_MODULE['<{dashgoals}prestashop>dashgoals_659e59f062c75f81259d22786d6c44aa'] = 'Vasaris';
$_MODULE['<{dashgoals}prestashop>dashgoals_fa3e5edac607a88d8fd7ecb9d6d67424'] = 'Kovas';
$_MODULE['<{dashgoals}prestashop>dashgoals_3fcf026bbfffb63fb24b8de9d0446949'] = 'Balandis';
$_MODULE['<{dashgoals}prestashop>dashgoals_195fbb57ffe7449796d23466085ce6d8'] = 'Gegužė';
$_MODULE['<{dashgoals}prestashop>dashgoals_688937ccaf2a2b0c45a1c9bbba09698d'] = 'Birželis';
$_MODULE['<{dashgoals}prestashop>dashgoals_1b539f6f34e8503c97f6d3421346b63c'] = 'Liepa';
$_MODULE['<{dashgoals}prestashop>dashgoals_41ba70891fb6f39327d8ccb9b1dafb84'] = 'Rugpjūtis';
$_MODULE['<{dashgoals}prestashop>dashgoals_cc5d90569e1c8313c2b1c2aab1401174'] = 'Rugsėjis';
$_MODULE['<{dashgoals}prestashop>dashgoals_eca60ae8611369fe28a02e2ab8c5d12e'] = 'Spalis';
$_MODULE['<{dashgoals}prestashop>dashgoals_7e823b37564da492ca1629b4732289a8'] = 'Lakpritis';
$_MODULE['<{dashgoals}prestashop>dashgoals_82331503174acbae012b2004f6431fa5'] = 'Gruodis';
$_MODULE['<{dashgoals}prestashop>dashgoals_e7935ae6c516d89405ec532359d2d75a'] = 'Srautas';
$_MODULE['<{dashgoals}prestashop>dashgoals_233d48e63da77b092da350559d2f8382'] = 'apsilankymai';
$_MODULE['<{dashgoals}prestashop>dashgoals_3bb1503332637805beddb73a2dd1fe1b'] = 'Konversija';
$_MODULE['<{dashgoals}prestashop>dashgoals_71241798130f714cbd2786df3da2cf0b'] = 'Vidutinė krepšelio vertė';
$_MODULE['<{dashgoals}prestashop>dashgoals_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Pardavimai';
$_MODULE['<{dashgoals}prestashop>dashgoals_9ac642c5ef334ea05256563f921bb304'] = 'Tikslas viršytas';
$_MODULE['<{dashgoals}prestashop>dashgoals_7c103c9bbbaecee07ca898ed65667cbf'] = 'Tikslas nepasiektas';
$_MODULE['<{dashgoals}prestashop>dashgoals_eb233580dc419f03df5905f175606e4d'] = 'Nustatytas tikslas:';
$_MODULE['<{dashgoals}prestashop>config_254f642527b45bc260048e30704edb39'] = 'Konfigūracija';
$_MODULE['<{dashgoals}prestashop>config_e7935ae6c516d89405ec532359d2d75a'] = 'Srautas';
$_MODULE['<{dashgoals}prestashop>config_e4c3da18c66c0147144767efeb59198f'] = 'Konversija';
$_MODULE['<{dashgoals}prestashop>config_8c804960da61b637c548c951652b0cac'] = 'Vidutinė krepšelio vertė';
$_MODULE['<{dashgoals}prestashop>config_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Pardavimai';
$_MODULE['<{dashgoals}prestashop>config_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_89c1265be62d3ba835a3d963db5956b0'] = 'Prognozė';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_f1206f9fadc5ce41694f69129aecac26'] = 'Konfigūruoti';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_63a6a88c066880c5ac42394a22803ca6'] = 'Atnaujinti';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_e7935ae6c516d89405ec532359d2d75a'] = 'Srautas';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_3bb1503332637805beddb73a2dd1fe1b'] = 'Konversija';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_8c804960da61b637c548c951652b0cac'] = 'Vidutinė krepšelio vertė';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Pardavimai';


return $_MODULE;
