<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{sekeywords}prestashop>sekeywords_65b0b42febc8ea16db4652eab6f420a4'] = 'Paieškos sistemos raktažodžiai';
$_MODULE['<{sekeywords}prestashop>sekeywords_8effa630c1740a748801b881acb90fa6'] = 'Parodo, kokie raktažodžiai atvedė lankytojus į Jūsų tinklapį.';
$_MODULE['<{sekeywords}prestashop>sekeywords_6602bbeb2956c035fb4cb5e844a4861b'] = 'Vedlys';
$_MODULE['<{sekeywords}prestashop>sekeywords_9ed50bd6876a9273f2192c224b87657b'] = 'Identifikuoti išorinių paieškos variklių raktažodžius';
$_MODULE['<{sekeywords}prestashop>sekeywords_7acbda50735929f05f6f463e05bc7ead'] = 'Tai yra vienas iš labiausiai paplitusių būdų rasti Jūsų tinklapį per paieškos variklius.';
$_MODULE['<{sekeywords}prestashop>sekeywords_4ad084c0b816ff9278765a00720caf32'] = 'Populiariausių raktažodžių, atvedusių naujus lankytojus, nustatymas leidžia Jums matyti prekes, kurias reikia iškelti į priekį, norint pasiekti geresnį matomumą paieškos varikliuose.';
$_MODULE['<{sekeywords}prestashop>sekeywords_359f9e79e746fa9f684e5cda9e60ca2e'] = 'Kaip tai veikia?';
$_MODULE['<{sekeywords}prestashop>sekeywords_ec2184245585ba979912af9e34d738c6'] = 'Kai lankytojas ateina į Jūsų svetainę, serveris atkreipia dėmesį iš kokių interneto svetainės adresų jis/ji ateina. Šis modulis suvokia URL, ir, jei randa nuorodą į žinomą paieškos variklį, nustato raktažodžius į jį.';
$_MODULE['<{sekeywords}prestashop>sekeywords_ef79a74a2fd296e19e8cc58cdae91d43'] = 'Šis modulis gali atpažinti visus paieškos variklius, pateiktus PrestaShop Statistikos/Paieškos variklių puslapyje -- ir Jūs galite pridėti dar daugiau!';
$_MODULE['<{sekeywords}prestashop>sekeywords_dcbcf5d190af87351a16edd5f132c657'] = 'SVARBI PASTABA: 2013 m. rugsėjo mėn. pasirinko užšifruoti paieškos užklausas naudodama SSL. Tai reiškia, kad visi nurodomis pagrįsti įrankiai pasaulyje (įskaitant ir šį) negali nustatyti Google raktažodžių.';
$_MODULE['<{sekeywords}prestashop>sekeywords_16d5f8dc3bc4411c85848ae9cf6a947a'] = '%d raktažodis atitinka jūsų užklausą.';
$_MODULE['<{sekeywords}prestashop>sekeywords_5029f8eef402bb8ddd6191dffb5e7c19'] = '%d raktažodžiai atitinka jūsų užklausą.';
$_MODULE['<{sekeywords}prestashop>sekeywords_0849140171616600e8f2c35f0a225212'] = 'Filtruoti pagal raktažodį';
$_MODULE['<{sekeywords}prestashop>sekeywords_6e632566b6e16dbd2273e83d7c53182b'] = 'Ir mažiausiai parodymų';
$_MODULE['<{sekeywords}prestashop>sekeywords_9639e32cab248434a17ab32237cb3b71'] = 'Taikyti';
$_MODULE['<{sekeywords}prestashop>sekeywords_867343577fa1f33caa632a19543bd252'] = 'Raktažodžiai';
$_MODULE['<{sekeywords}prestashop>sekeywords_e52e6aa1a43a0187e44f048f658db5f9'] = 'Pasirodymai';
$_MODULE['<{sekeywords}prestashop>sekeywords_998e4c5c80f27dec552e99dfed34889a'] = 'CSV eksportas';
$_MODULE['<{sekeywords}prestashop>sekeywords_7b48f6cc4a1dde7fca9597e717c2465f'] = 'Nėra raktažodžių';
$_MODULE['<{sekeywords}prestashop>sekeywords_e15832aa200f342e8f4ab580b43a72a8'] = 'Pirmieji 10 raktažodžių';
$_MODULE['<{sekeywords}prestashop>sekeywords_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Kiti';


return $_MODULE;
