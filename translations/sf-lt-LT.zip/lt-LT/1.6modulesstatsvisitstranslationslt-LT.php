<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsvisits}prestashop>statsvisits_504c16c26a96283f91fb46a69b7c8153'] = 'Apsilankymai ir lankytojai';
$_MODULE['<{statsvisits}prestashop>statsvisits_432c3ab90b3af30ad318201ba09aa824'] = 'Prideda statistiką apie jūsų klientus į Statistikos valdymo panelę.';
$_MODULE['<{statsvisits}prestashop>statsvisits_6602bbeb2956c035fb4cb5e844a4861b'] = 'Vedlys';
$_MODULE['<{statsvisits}prestashop>statsvisits_ffbee337f031c2282b311bac40bc8bb9'] = 'Nustatykite apsilankymo tikslą';
$_MODULE['<{statsvisits}prestashop>statsvisits_e90d50ca1e68dc66c97bd62929dcbaf1'] = 'Lankytojo evoliucijos grafikas labai panašus į apsilankymo grafiką, tačiau suteikia papildomos informacijos:';
$_MODULE['<{statsvisits}prestashop>statsvisits_e9849ece0b2ecf1eea74d92d492a47f2'] = 'Šiuo atveju sveikiname, jūsų svetainė gerai suplanuota ir patogi. Malonu, kad jūs atkreipiate dėmesį.';
$_MODULE['<{statsvisits}prestashop>statsvisits_c745121a98cf1d5b26bc5299d9880d5c'] = 'Priešingu atveju, išvada ne tokia paprasta. Problema gali būti estetinė arba ergonominė. Taip pat įmanoma kad daug lankytojų įvedė jūsų URL per klaidą, neturėdami tikslo aplankyti būtent jūsų parduotuvę. Šį keistą ir painų fenomeną dažniausiai sukelia paieškos varikliai. Šiuo atveju jūs turėtumėte peržiūrėti savo SEO struktūrą.';
$_MODULE['<{statsvisits}prestashop>statsvisits_9bf5a493522a65d550f096505874873b'] = 'Ši informacija daugiausiai kokybinė. Jūs pats turite nuspręsti dėl ko atsitiko šis apsilankymas.';
$_MODULE['<{statsvisits}prestashop>statsvisits_b8901fb7bbfaf9b0c4724343c7cd1f90'] = 'Laikas nuo interneto vartotojo atėjimo į jūsų parduotuvę iki jo sesijos pabaigos skaičiuojamas kaip vienas apsilankymas.';
$_MODULE['<{statsvisits}prestashop>statsvisits_f43a4cf6dcc4ec617d2296d03d26c90f'] = 'Lankytojas yra nežinomas asmuo kuris nėra prisiregistravęs ar prisijungęs prie jūsų parduotuvės. Lankytoju taip pat gali būti laikomas asmuo kuris lankėsi jūsų parduotuvėje keletą kartų.';
$_MODULE['<{statsvisits}prestashop>statsvisits_54067074d24489ddb5654bf46642cb85'] = 'Viso apsilankymų:';
$_MODULE['<{statsvisits}prestashop>statsvisits_23e640d55e56db79971918936e95bf9d'] = 'Viso lankytojų:';
$_MODULE['<{statsvisits}prestashop>statsvisits_998e4c5c80f27dec552e99dfed34889a'] = 'CSV eksportas';
$_MODULE['<{statsvisits}prestashop>statsvisits_39b960b0a5e2ebaaa638d946f1892050'] = 'Aspilankymų ir unikalių lankytojų skaičius';
$_MODULE['<{statsvisits}prestashop>statsvisits_d7e637a6e9ff116de2fa89551240a94d'] = 'Apsilankymai';
$_MODULE['<{statsvisits}prestashop>statsvisits_ae5d01b6efa819cc7a7c05a8c57fcc2c'] = 'Lankytojai';


return $_MODULE;
