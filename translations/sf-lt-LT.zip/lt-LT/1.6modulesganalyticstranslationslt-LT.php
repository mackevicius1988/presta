<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{ganalytics}prestashop>ganalytics_d86cf69a8b82547a94ca3f6a307cf9a6'] = 'Google Analytics';
$_MODULE['<{ganalytics}prestashop>ganalytics_135d2522825fa02688ab25a2e1c88c73'] = 'Gaukite svarbias ir aiškias įžvalgas, metrikas apie savo klientus, naudojant Google Analitiką';
$_MODULE['<{ganalytics}prestashop>ganalytics_7ed5c154078e30b30b2f214299c5e9f5'] = 'Ar tikrai norite išdiegti Google Analitiką? Jūs prarasite visus duomenis, kuriuos surinko šis modulis.';
$_MODULE['<{ganalytics}prestashop>ganalytics_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{ganalytics}prestashop>ganalytics_630f6dc397fe74e52d5189e2c80f282b'] = 'Atgal į sąrašą';
$_MODULE['<{ganalytics}prestashop>ganalytics_f4f70727dc34561dfde1a3c529b6205c'] = 'Nustatymai';
$_MODULE['<{ganalytics}prestashop>ganalytics_851bd83a102d143ee17d97f9e15e15af'] = 'Google Analitikos sekimo ID';
$_MODULE['<{ganalytics}prestashop>ganalytics_ad8e83a47926dcb12e8a8fccd7fcf604'] = 'Ši informacija prieinama jūsų Google Analitkos paskyroje';
$_MODULE['<{ganalytics}prestashop>ganalytics_bcd08e73ca9d8bfed2cccd50dd6d8328'] = 'Įjungti vartotojų ID sekimą';
$_MODULE['<{ganalytics}prestashop>ganalytics_9bda6a2c3edca377eb901d7ea57c8b06'] = 'Vartotojo ID yra nustatytas savybės lygmenyje. Norėdami rasti savybę, paspauskite Admin, pasirinkite paskyrą ir savybę. Savybės stulpelyje paspauskite Sekimo informacija, tada vartotojo ID';
$_MODULE['<{ganalytics}prestashop>ganalytics_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Įjungta';
$_MODULE['<{ganalytics}prestashop>ganalytics_b9f5c797ebbf55adccdd8539a65a0241'] = 'Išjungta';
$_MODULE['<{ganalytics}prestashop>ganalytics_612e1a524ec979815b12182c34e2daa0'] = 'Paskyros ID atnaujintas sėkmingai';
$_MODULE['<{ganalytics}prestashop>ganalytics_8e7b67b44506b7ac6685da041a603044'] = 'Vartotojo ID nustatymai sėkmingai atnaujinti';
$_MODULE['<{ganalytics}prestashop>configuration_1f13d86a35be758509f9bdfcce5ec55d'] = 'Jūsų klientai naršo po visus puslapius. Ar neturėtumėte apie tai žinoti ir jūs?';
$_MODULE['<{ganalytics}prestashop>configuration_7063e771c3bb338ba74ac4e4716dbae1'] = 'Google analitika rodo pilną informaciją apie jūsų klientus, surinktą iš reklamų, video, svetainių ir soc. tinklų, planšečių ir telefonų. Ši informacija palengvins jūsų darbą su esamais klientais ir padės jums pritraukti naujų.';
$_MODULE['<{ganalytics}prestashop>configuration_df15c5cf264eb769b087f9d81aff029f'] = 'Su Google Analitikos el. komercijos funkcijomis galite rinkti svarbias metrikas apie pirkėjų elgesį ir pirkimus, taip pat sužinoti apie:';
$_MODULE['<{ganalytics}prestashop>configuration_613c191b4a1f82a454b72a840d96eefd'] = 'Prekės aprašymo peržiūras';
$_MODULE['<{ganalytics}prestashop>configuration_d88b192dfe623e2a628a919b99fc1a4b'] = 'Pardavimų strategijos progresą';
$_MODULE['<{ganalytics}prestashop>configuration_ade6a18bb6c147db87bc9463240e455a'] = '"Pridėti į krepšelį" veiksmus';
$_MODULE['<{ganalytics}prestashop>configuration_c975b6b93d71b19da73114c4adcedbda'] = 'Užsakymo sudarymo procesą';
$_MODULE['<{ganalytics}prestashop>configuration_33f50b54625790316b86485ff3e794c4'] = 'Reklaminių akcijų populiarumą';
$_MODULE['<{ganalytics}prestashop>configuration_89c48ff165eedcc3cd1bd0007115669d'] = 'Ir apie pirkimus';
$_MODULE['<{ganalytics}prestashop>configuration_4632d86a96205013262bcfdd0279b39f'] = 'Pardavėjai turi galimybę suprasti, kiek žingsnių apsipirkimo procese atlieka pirkėjais ir kur jie nutraukia procesą.';
$_MODULE['<{ganalytics}prestashop>configuration_16fafb5cce24f766bf2c8fcebecf76fc'] = 'Jei norite pradėti, susikurkite sau paskyrą.';
$_MODULE['<{ganalytics}prestashop>form-ps14_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';


return $_MODULE;
