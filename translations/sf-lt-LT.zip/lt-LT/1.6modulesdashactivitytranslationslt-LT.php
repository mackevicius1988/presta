<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{dashactivity}prestashop>dashactivity_0369e7f54bf8a30b2766e6a9a708de0b'] = 'Skydelis Aktyvumas';
$_MODULE['<{dashactivity}prestashop>dashactivity_02b5205ddff3073efc5c8b5b9cc165ba'] = '(nuo %s iki %s)';
$_MODULE['<{dashactivity}prestashop>dashactivity_14542f5997c4a02d4276da364657f501'] = 'Tiesioginė nuoroda';
$_MODULE['<{dashactivity}prestashop>dashactivity_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{dashactivity}prestashop>dashactivity_ea4788705e6873b424c65e91c2846b19'] = 'Atšaukti';
$_MODULE['<{dashactivity}prestashop>dashactivity_914030b0a079e4eec3b3f5090c0fc35a'] = 'Aktyvūs krepšeliai';
$_MODULE['<{dashactivity}prestashop>dashactivity_78fa968db0e87c6fc302614b26f93b5d'] = 'Kiek laiko (minutėmis) krepšelis dar laikomas aktyviu po paskutinio veiksmo svetainėje (numatytoji reikšmė: 30 min).';
$_MODULE['<{dashactivity}prestashop>dashactivity_47b8a33a5335cce8d4e353c4d1743f31'] = 'Naršantys lankytojai';
$_MODULE['<{dashactivity}prestashop>dashactivity_b13a895857368f29e5e127767388b0ab'] = 'Kiek laiko (minutėmis) vartotojas laikomas aktyviu po paskutinio veiksmo svetainėje (numatytoji reikšmė: 30 min).';
$_MODULE['<{dashactivity}prestashop>dashactivity_6ad366c171531a83ffbc5625e159f340'] = 'Apleisti krepšeliai (min)';
$_MODULE['<{dashactivity}prestashop>dashactivity_8f1f252cfd3cbbcba7a2325f12e3dbc4'] = 'Praėjus kiek laiko (valandomis) po paskutinio veiksmo krepšelis laikomas apleistu (numatytoji reikšmė: 24 val.).';
$_MODULE['<{dashactivity}prestashop>dashactivity_c760237f74bcc7e3f90ad956086edb66'] = 'val';
$_MODULE['<{dashactivity}prestashop>dashactivity_a5493eb7cba36f452249d093e7757adc'] = 'Apleisti krepšeliai (max)';
$_MODULE['<{dashactivity}prestashop>dashactivity_45e9c82415a3bee4413485c6bcb4347f'] = 'Praėjus kiek laiko (valandomis) po paskutinio veiksmo krepšelis laikomas apleistu (numatytoji reikšmė: 24 val).';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_91b1b529580f2bb429493a51a1af932b'] = 'Aktyvumo peržiūra';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_f1206f9fadc5ce41694f69129aecac26'] = 'Konfigūruoti';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_63a6a88c066880c5ac42394a22803ca6'] = 'Atnaujinti';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_254f642527b45bc260048e30704edb39'] = 'Konfigūracija';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_edfc5fccc0439856b5bd432522ef47aa'] = 'Šiuo metu naršantys lankytojai';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_962b7da7912bc637b03626e23b5832b5'] = 'per paskutines %d min.';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_7aaacf26dbf7d8929916618bb57d81f8'] = 'Aktyvių pirkinių krepšelių';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_24042b0e4b783724dac4178df4db5d68'] = 'Dabar laukia';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Užsakymai';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_247d96cbab5bfc79dff10eb2ce6d8897'] = 'Grąžinimų/pakeitimų';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_54e85d70ea67acdcc86963b14d6223a8'] = 'Apleisti krepšeliai';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_1c4407dd95b9ef941d30c2838208977e'] = 'Išparduotos prekės';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_a274f4d4670213a9045ce258c6c56b80'] = 'Pranešimai';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_a644e8cd597f2b92aa52861632c0363d'] = 'Naujų žinučių';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_56d4e9a4c8e9f47549e8129393b3740f'] = 'Prekių aprašymai';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_e539ae01694149c9e12295fe564a376b'] = 'Pirkėjų ir naujienlaiškių';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_8471314b4a53476fbf2379d9a0f7ac28'] = 'Naujų pirkėjų';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_d833d1b3c98b980090f79ad42badcf9f'] = 'Naujų prenumeratų';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_e42bc03dcf18091455cb8a06ce1d56e9'] = 'Iš viso prenumeratorių';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_e7935ae6c516d89405ec532359d2d75a'] = 'Srautas';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_1a4aeb4ca6cd736a4a7b25d8657d9972'] = 'Nuoroda į Google Analytics paskyrą';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_d7e637a6e9ff116de2fa89551240a94d'] = 'Apsilankymai';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_945f170a18e4894c90381a3d01bdef8b'] = 'Unikalių lankytojų';
$_MODULE['<{dashactivity}prestashop>dashboard_zone_one_0fcff541ec15c6ed895d5dec49436488'] = 'Srauto šaltiniai';


return $_MODULE;
