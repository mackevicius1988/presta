<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{dashproducts}prestashop>dashproducts_6655df4af87b2038afd507a33545a56d'] = 'Skydelis Prekės';
$_MODULE['<{dashproducts}prestashop>dashproducts_4a528e24be5aca96e8a15b256efe1f31'] = 'Prideda bloką su paskutinių užsakymų lentele ir prekių reitingu';
$_MODULE['<{dashproducts}prestashop>dashproducts_2ea989f83006e233627987293f4bde0a'] = 'Klientas';
$_MODULE['<{dashproducts}prestashop>dashproducts_068f80c7519d0528fb08e82137a72131'] = 'Prekės';
$_MODULE['<{dashproducts}prestashop>dashproducts_96b0141273eabab320119c467cdcaf17'] = 'Viso';
$_MODULE['<{dashproducts}prestashop>dashproducts_58ef6750a23ba432fc1377b7de085d9f'] = 'be PVM';
$_MODULE['<{dashproducts}prestashop>dashproducts_44749712dbec183e983dcd78a7736c41'] = 'Data';
$_MODULE['<{dashproducts}prestashop>dashproducts_ec53a8c4f07baed5d8825072c89799be'] = 'Būsena';
$_MODULE['<{dashproducts}prestashop>dashproducts_3ec365dd533ddb7ef3d1c111186ce872'] = 'Išsamiau';
$_MODULE['<{dashproducts}prestashop>dashproducts_be53a0541a6d36f6ecb879fa2c584b08'] = 'Nuotrauka';
$_MODULE['<{dashproducts}prestashop>dashproducts_deb10517653c255364175796ace3553f'] = 'Prekė';
$_MODULE['<{dashproducts}prestashop>dashproducts_3adbdb3ac060038aa0e6e6c138ef9873'] = 'Kategorija';
$_MODULE['<{dashproducts}prestashop>dashproducts_2aed3d711270a6ed67d21ec2d7cd4af8'] = 'Parduota iš viso';
$_MODULE['<{dashproducts}prestashop>dashproducts_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Pardavimai';
$_MODULE['<{dashproducts}prestashop>dashproducts_9e79098315622e58529d664b9a8b3cf8'] = 'Pelnas';
$_MODULE['<{dashproducts}prestashop>dashproducts_ed4832a84ee072b00a6740f657183598'] = 'Peržiūros';
$_MODULE['<{dashproducts}prestashop>dashproducts_2c04f1ad7694378897b98624780327ff'] = 'Pridėta į krepšelį';
$_MODULE['<{dashproducts}prestashop>dashproducts_ce4ee01637f4279d02d0f232459dc9a4'] = 'Nupirkta';
$_MODULE['<{dashproducts}prestashop>dashproducts_37be07209f53a5d636d5c904ca9ae64c'] = 'Procentas';
$_MODULE['<{dashproducts}prestashop>dashproducts_1eb18ea1d018abef5759cef60ddc289b'] = 'Privalote įjungti "Išsaugoti globalias puslapių peržiūras" nustatymą iš "Duomenų rinkimo statistikai" modulio, jei norite matyti labiausiai žiūrimą prekę, arba naudoti Google Analytics modulį.';
$_MODULE['<{dashproducts}prestashop>dashproducts_cf5f3091e30dee6597885d8c0e0c357f'] = 'Terminas';
$_MODULE['<{dashproducts}prestashop>dashproducts_13348442cc6a27032d2b4aa28b75a5d3'] = 'Paieška';
$_MODULE['<{dashproducts}prestashop>dashproducts_fd69c5cf902969e6fb71d043085ddee6'] = 'Rezultatai';
$_MODULE['<{dashproducts}prestashop>dashproducts_38fb7d24e0d60a048f540ecb18e13376'] = '   Išsaugoti   ';
$_MODULE['<{dashproducts}prestashop>dashproducts_ea4788705e6873b424c65e91c2846b19'] = 'Atšaukti';
$_MODULE['<{dashproducts}prestashop>dashproducts_85bf7474324d7d02725e4dca586afcd9'] = 'Kiek rodyti "Naujausių užsakymų"';
$_MODULE['<{dashproducts}prestashop>dashproducts_735b8c7f6d50b4c6f818deeab3cdea4a'] = 'Kiek rodyti "Daugiausiai perkamų"';
$_MODULE['<{dashproducts}prestashop>dashproducts_14d24dddc4c67abf8364b980b2ccd5a2'] = 'Kiek rodyti "Daugiausiai žiūrimų"';
$_MODULE['<{dashproducts}prestashop>dashproducts_f1ee1eaab342241138d45f35f4d8466a'] = 'Kiek rodyti "Ieškomiausių"';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_3e361ce73ecabd6524af286d55809ed7'] = 'Prekės ir pardavimai';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_f1206f9fadc5ce41694f69129aecac26'] = 'Konfigūruoti';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_63a6a88c066880c5ac42394a22803ca6'] = 'Atnaujinti';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_254f642527b45bc260048e30704edb39'] = 'Konfigūracija';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_fd3458547ef9c3a8bd0e1e1b4ef2b4dd'] = 'Naujausi užsakymai';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_d7b2933ba512ada478c97fa43dd7ebe6'] = 'Geriausiai parduodamos';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_be5006eb5af9ab6dbca803f8d3065bbc'] = 'Daugiausiai žiūrimi';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_1eb5e5713d7363e921dd7f5500b6d212'] = 'Ieškomiausi';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_3d23ac9ab254a9f1014c3a859b01bcfc'] = 'Paskutiniai užsakymai (%d)';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_82f0f8d535196ce2a6ea16652d981f94'] = 'Perkamiausių prekių top %d';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_5da618e8e4b89c66fe86e32cdafde142'] = 'Nuo';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_01b6e20344b68835c5ed1ddedf20d531'] = 'iki';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_1daaca459ce1e6610e0b97a9ad723f27'] = 'Ieškomų terminų top %d';


return $_MODULE;
