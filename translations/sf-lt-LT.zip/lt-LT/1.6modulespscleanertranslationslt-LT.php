<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{pscleaner}prestashop>pscleaner_e5a8af934462c05509c7de5f2f2c18a3'] = 'PrestaShop išvalymas';
$_MODULE['<{pscleaner}prestashop>pscleaner_4bcb9cc248b7f6c8dc7f5c323bde76de'] = 'Patikrinti ir pataisyti integralumo sąsajas ir pašalinti duomenis pagal nutylėjimą';
$_MODULE['<{pscleaner}prestashop>pscleaner_752369f18aebeed9ae8384d8f1b5dc5e'] = 'Būkite atsargūs su šiuo įrankiu - jame nėra galimybės atstatyti ankstesnę būseną!';
$_MODULE['<{pscleaner}prestashop>pscleaner_550b877b1a255ba717cfad4b82057731'] = 'Šios užklausos sėkmingai pataisė sugadintus duomenis:';
$_MODULE['<{pscleaner}prestashop>pscleaner_14a7ab23d566b4505d0c711338c19a08'] = '%d eilutė(s)';
$_MODULE['<{pscleaner}prestashop>pscleaner_d1ff3c9d57acd4283d2793a36737479e'] = 'Nieko nereikia taisyti';
$_MODULE['<{pscleaner}prestashop>pscleaner_53d097f11855337bb74f1444d6c47c99'] = 'Šios užklausos sėkmingai išvalė jūsų duomenų bazę:';
$_MODULE['<{pscleaner}prestashop>pscleaner_098c3581a731f08d24311bbf515adbbb'] = 'Nėra ką valyti';
$_MODULE['<{pscleaner}prestashop>pscleaner_1bb7c5eb8682aeada82c407b40ec09c8'] = 'Katalogas išvalytas';
$_MODULE['<{pscleaner}prestashop>pscleaner_ed6ecb7169d5476ef5251524bb17552a'] = 'Užsakymai ir pirkėjai išvalyti';
$_MODULE['<{pscleaner}prestashop>pscleaner_43364f357f96e8b70be4a44d44196807'] = 'Perskaitykite "disclaimer" ir paspauskite aukščiau esantį "Taip"';
$_MODULE['<{pscleaner}prestashop>pscleaner_6c69628e1d57fa6e39162b039a82133b'] = 'Ar jūs tikrai norite ištrinti visus katalogo duomenis?';
$_MODULE['<{pscleaner}prestashop>pscleaner_6a68264705f23c8e3d505fd2c93a87ba'] = 'Ar jūs tikrai norite ištrinti visus pardavimų duomenis?';
$_MODULE['<{pscleaner}prestashop>pscleaner_c32516babc5b6c47eb8ce1bfc223253c'] = 'Katalogas';
$_MODULE['<{pscleaner}prestashop>pscleaner_da69e50b7440e12fe63287904819eaa3'] = 'Aš suprantu, kad katalogo duomenys bus pašalinti be atstatymo galimybės: produktai, ypatybės, kategorijos, žymos, paveiksliukai, kainos, prikabinami failai, sandėliai, požymių grupės ir reikšmės, gamintojai, tiekėjai...';
$_MODULE['<{pscleaner}prestashop>pscleaner_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Įjungta';
$_MODULE['<{pscleaner}prestashop>pscleaner_b9f5c797ebbf55adccdd8539a65a0241'] = 'Išjungta';
$_MODULE['<{pscleaner}prestashop>pscleaner_b2d7c99e984831bd36221baf34e9c26e'] = 'Ištrinti katalogą';
$_MODULE['<{pscleaner}prestashop>pscleaner_3300d0bf086fa38cf593fe4feff351f1'] = 'Užsakymai ir pirkėjai';
$_MODULE['<{pscleaner}prestashop>pscleaner_a01f9a9a340c3c68a2dc4663f46d8637'] = 'Aš suprantu, kad visi užsakymai ir pirkėjai bus pašalinti be atstatymo galimybės: pirkėjai, krepšeliai, užsakykmai, ryšiai, svečiai, pranešimai, statistika...';
$_MODULE['<{pscleaner}prestashop>pscleaner_17ca7f22baf84821b6b73462c96fb1e3'] = 'Ištrinti užsakymus ir pirkėjus';
$_MODULE['<{pscleaner}prestashop>pscleaner_3535aa31bd9005bde626ad4312b67d6b'] = 'Funkcinės integralumo sąsajos';
$_MODULE['<{pscleaner}prestashop>pscleaner_e84c6595e849214a70b35ed8f95d7d16'] = 'Patikrinti ir pataisyti';
$_MODULE['<{pscleaner}prestashop>pscleaner_ccc27439e3e08c444690af3bed668e2d'] = 'Duomenų bazės valymas';
$_MODULE['<{pscleaner}prestashop>pscleaner_39707b9cfefe433d64f695623d2d3fd7'] = 'Valyti ir optimizuoti';


return $_MODULE;
