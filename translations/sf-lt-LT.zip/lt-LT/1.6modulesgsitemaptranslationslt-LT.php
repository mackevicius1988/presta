<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{gsitemap}prestashop>gsitemap_3aaaafde6f9b2701f9e6eb9292e95521'] = 'Google svetainės žemėlapis';
$_MODULE['<{gsitemap}prestashop>gsitemap_935a6bc13704a117d22333c3155b5dae'] = 'Generuoti Google svetainės žemėlapio bylą';
$_MODULE['<{gsitemap}prestashop>gsitemap_b52bf50c73995780892b9945ddc98708'] = 'Tikrinant jūsų teises įvyko klaida. Pataisykite teises, kad PrestaShop galėtų rašyti į failą jūsų šakniniame (root) kataloge.';
$_MODULE['<{gsitemap}prestashop>configuration_67ddb0d12fa1963b202d4ac310547709'] = 'Jūsų svetainės žemėlapis sėkmingai sukurtas. Nepamirškite nurodyti URL';
$_MODULE['<{gsitemap}prestashop>configuration_9d934413d2737c2a15f58de573657ce3'] = 'jūsų "Google Webmaster" paskyroje.';
$_MODULE['<{gsitemap}prestashop>configuration_1c95b77d135b55c84429588c11697ea4'] = 'Jūsų svetainės žemėlapiai';
$_MODULE['<{gsitemap}prestashop>configuration_aa17b80751f4ae53ab8e3ed2fe99e94d'] = 'Svetainės žemėlapiai jau buvo sukurti.';
$_MODULE['<{gsitemap}prestashop>configuration_a0bfb8e59e6c13fc8d990781f77694fe'] = 'Tęsti';
$_MODULE['<{gsitemap}prestashop>configuration_9ab08b9ceeef857df07ad10e1de9301e'] = 'Nustatykite šį svetainės žemėlapio URL savo Google Webmaster paskyroje:';
$_MODULE['<{gsitemap}prestashop>configuration_aef717e48ecd01989c92849d44bff9b6'] = 'Šis URL yra pagrindinis svetainės žemėlapio failas. Jis įtraukia šiuos smulkesnius svetainės žemėlapio failus:';
$_MODULE['<{gsitemap}prestashop>configuration_0dbf904a2b27f036cf06741aad221ecc'] = 'Paskutinis atnaujinimas buvo atliktas:';
$_MODULE['<{gsitemap}prestashop>configuration_6d37779958434303f8397436a1484ed8'] = 'Geresniam modulio naudojimui, įsitikinkite kad jūs turite';
$_MODULE['<{gsitemap}prestashop>configuration_6a3282611e5ffb8539ce434133073f15'] = 'minimali memory_limit reikšmė - 128 MB.';
$_MODULE['<{gsitemap}prestashop>configuration_f891951357d4892887f0e416c54f972d'] = 'minimali max_execution_time reikšmė - 30 sekundžių.';
$_MODULE['<{gsitemap}prestashop>configuration_8156303464de0fba7cb8306cc768e998'] = 'Galite pakeisti šiuos limitus savo php.ini faile. Norėdami sužinoti detaliau, susisiekite su savo svetainės talpinimo tiekėju.';
$_MODULE['<{gsitemap}prestashop>configuration_0b9b4b91e0a8f59e264202a23d9c57a6'] = 'Konfigūruoti svetainės medį';
$_MODULE['<{gsitemap}prestashop>configuration_fe242b3dd3f455778072dc7042637a5e'] = 'Bus sugeneruoti keli svetainės žemėlapio failai, priklausomai nuo to, kaip sukonfigūruotas jūsų serveris ir nuo to, kiek yra aktyvių prekių jūsų kataloge.';
$_MODULE['<{gsitemap}prestashop>configuration_7f751d19f85d49a411d5691f5bb0b5f2'] = 'Kaip dažnai norite atnaujinti savo parduotuvę?';
$_MODULE['<{gsitemap}prestashop>configuration_f9f90eeaf400d228facde6bc48da5cfb'] = 'visuomet';
$_MODULE['<{gsitemap}prestashop>configuration_745fd0ea7f576f350a0eed4b8c48a8e2'] = 'kas valandą';
$_MODULE['<{gsitemap}prestashop>configuration_bea79186fd7af2da67e59b4b15df5a26'] = 'kasdieną';
$_MODULE['<{gsitemap}prestashop>configuration_4a11fc05ed694c195f0703605b64da90'] = 'kas savaitę';
$_MODULE['<{gsitemap}prestashop>configuration_708638881f3bac9d9c8c742c79502811'] = 'kas mėnesį';
$_MODULE['<{gsitemap}prestashop>configuration_1bf712896e6077fa0b708e911d8ee0b3'] = 'kasmet';
$_MODULE['<{gsitemap}prestashop>configuration_c7561db7a418dd39b2201dfe110ab4a4'] = 'niekada';
$_MODULE['<{gsitemap}prestashop>configuration_e51d91c7bfa9fc658b11afca4d84653c'] = 'Pažymėkite šią varnelę jei norite tikrinti ar serveryje egzistuoja paveiksliukų failai';
$_MODULE['<{gsitemap}prestashop>configuration_05ff8159ccaef6f0f8391c61a6d0e631'] = 'pažymėti visus';
$_MODULE['<{gsitemap}prestashop>configuration_0dfcf5f2f5b9ab7c909f9bdca2b53b56'] = 'Nurodykite puslapius, kurių nenorite įtraukti į svetainės žemėlapio failą:';
$_MODULE['<{gsitemap}prestashop>configuration_2ec111ec9826a83509c02bf5e6b797f1'] = 'Generuoti svetainės žemėlapį';
$_MODULE['<{gsitemap}prestashop>configuration_ca99f8a0d484faef3a057fe7a5da3141'] = 'Tai gali užtrukti kelias minutes';
$_MODULE['<{gsitemap}prestashop>configuration_162b34489ed8df561be1720f04fe6d42'] = 'Yra du būdai sugeneruoti svetainės žemėlapį:';
$_MODULE['<{gsitemap}prestashop>configuration_6caa369fd774beef106abbc5cc1e3368'] = 'Rankomis:';
$_MODULE['<{gsitemap}prestashop>configuration_4ed0b6a0097c3d38c43d756fe2653962'] = 'naudojant aukščiau esančią formą (taip dažnai, kaip reikia)';
$_MODULE['<{gsitemap}prestashop>configuration_3d263eb0233f14872193733387840c80'] = '-arba-';
$_MODULE['<{gsitemap}prestashop>configuration_957d27165d1dc5947fb00e57967ffcce'] = 'Automatiškai:';
$_MODULE['<{gsitemap}prestashop>configuration_024d2d2f6d7fd575701fd1b30cc5c0c2'] = 'Paprašykite jūsų hostingo tiekėjo nustatyti "cron darbą" kuris užkrautų šį URL jūsų pageidaujamu laiku:';
$_MODULE['<{gsitemap}prestashop>configuration_8076be06e575e50c7f9585271c8842ad'] = 'Jis automatiškai sugeneruos XML svetainės žemėlapius.';
$_MODULE['<{gsitemap}prestashop>configuration_98a9d595be84a0687c4b26887977e0c3'] = 'nežymėti visų';


return $_MODULE;
