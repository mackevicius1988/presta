<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Pritaikytas TVS informacijos blokas';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Prideda pritaikytą informacijos bloką jūsų parduotuvei.';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_666f6333e43c215212b916fef3d94af0'] = 'Užpildykite visus laukus.';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_86432715902fbaf53de469fed3fa6c53'] = 'Jūs turite pasirinkti bent vieną parduotuvę.';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Bandant išsaugoti įvyko klaida.';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Naujas pritaikytas TVS blokas';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Tekstas';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Atgal į sąrašą';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_9d55fc80bbb875322aa67fd22fc98469'] = 'Parduotuvių asociacija:';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_6fcdef6ca2bb47a0cf61cd41ccf274f4'] = 'Bloko ID';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_9f82518d468b9fee614fcc92f76bb163'] = 'Parduotuvė:';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_56425383198d22fc8bb296bcca26cecf'] = 'Teksto blokas';
$_MODULE['<{blockcmsinfo}prestashop>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Pridėti naują';


return $_MODULE;
