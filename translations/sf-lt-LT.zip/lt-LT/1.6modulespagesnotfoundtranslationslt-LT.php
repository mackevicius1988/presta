<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Nerasti puslapiai';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_607cc8b8993662a37cac86032fb071d2'] = 'Prideda skirtuką į statistikos skydelį, rodantį puslapius, kurie nebuvo rasti Jūsų lankytojams.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_dc3a3db6b98723bf91f924537a630600'] = '"Nerasti puslapiai" talpykla išvalyta.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_b323790d8ee3c43d317d19aea5012626'] = '"Nerasti puslapiai" talpykla ištrinta.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Vedlys';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = '404 klaidos';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_675f1f46497aeeee35832a5d9d095976'] = '404 klaida yra HTML klaidos kodas, kuris reiškia, kad vartotojo prašomas failas negali būti rastas. Jūsų atveju tai reiškia, kad vienas iš jūsų lankytojų įvedė neteisingą URL adreso juostoje arba Jūs ar kita svetainė turi neteisingą nuorodą. Kai yra įmanoma, referentas yra rodomas, todėl Jūs galite rasti puslapį/svetainę su bloga nuoroda. Jei ne, tai paprastai reiškia, kad yra tiesioginė prieiga, todėl kažkas galėjo pažymėti nuorodą, kuri jau neegzistuoja.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'Kaip ištaisyti šias klaidas?';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_4f803d59ee120b11662027e049cba1f3'] = 'Jei Jūsų tinklo serveris palaiko .htaccess failus, Jūs galite sukurti PrestaShop šakninį katalogą ir viduje įterpti eilutę: "%s".';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_07e7f83ae625fe216a644d09feab4573'] = 'Vartotojas, kreipdamasis į puslapį, kuris neegzistuoja, bus nukreipiamas į šį puslapį: %s. Šis modulis rastų prieigą prie šio puslapio.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_01bd0bf7c5a68ad6ee4423118be3f7b6'] = 'Turite naudoti .htaccess failą, kad nukreipti 404 errors į "404.php" puslapį.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Puslapis';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referentas';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Skaitliukas';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_4a7a7e7cda40454cee7ec247660f8017'] = 'Šiuo metu neregistruota nė viena "nerasti puslapiai" problema.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Išvalyti duomenų bazę';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_b9ae3636d6e672413a163f7cb34beb84'] = 'Išvalyti VISUS "nerasti puslapiai" pranešimus šiuo periodu';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_0cf5c3a279c0e8c57b232d8c6bc3f06a'] = 'Išvalyti VISUS „puslapis nerastas“ pranešimus';


return $_MODULE;
