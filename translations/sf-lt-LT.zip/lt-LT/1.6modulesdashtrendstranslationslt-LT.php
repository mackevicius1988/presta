<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{dashtrends}prestashop>dashtrends_ee653ade5f520037ef95e9dc2a42364c'] = 'Skydelis Tendencijos';
$_MODULE['<{dashtrends}prestashop>dashtrends_f2d0efa68eb71bfd5209abeb9f4b0943'] = 'Pridėti blokelį, kuriame grafiškai atvaizduojamos jūsų parduotuvės vystymosi tendencijos pagal pasirinktą duomenų tipą.';
$_MODULE['<{dashtrends}prestashop>dashtrends_2d125dc25b158f28a1960bd96a9fa8d1'] = '%s taškai';
$_MODULE['<{dashtrends}prestashop>dashtrends_887ee91702c962a70b87cbef07bbcaec'] = 'be PVM';
$_MODULE['<{dashtrends}prestashop>dashtrends_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Pardavimai';
$_MODULE['<{dashtrends}prestashop>dashtrends_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Užsakymai';
$_MODULE['<{dashtrends}prestashop>dashtrends_8c804960da61b637c548c951652b0cac'] = 'Vidutinė krepšelio vertė';
$_MODULE['<{dashtrends}prestashop>dashtrends_d7e637a6e9ff116de2fa89551240a94d'] = 'Apsilankymai';
$_MODULE['<{dashtrends}prestashop>dashtrends_e4c3da18c66c0147144767efeb59198f'] = 'Konversija';
$_MODULE['<{dashtrends}prestashop>dashtrends_43d729c7b81bfa5fc10e756660d877d1'] = 'Pelnas';
$_MODULE['<{dashtrends}prestashop>dashtrends_46418a037045b91e6715c4da91a2a269'] = '%s (ankstesnis periodas)';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_2938c7f7e560ed972f8a4f68e80ff834'] = 'Skydelis';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_f1206f9fadc5ce41694f69129aecac26'] = 'Konfigūruoti';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_63a6a88c066880c5ac42394a22803ca6'] = 'Atnaujinti';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_e537825dd409a90ef70d8c2eb56122a1'] = 'Pajamų suma (be PVM), sugeneruota iš užsakymų per laikotarpį, kuris laikomas patvirtintu.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Pardavimai';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_8bc1c5ca521b99b87908db0bcd33ec76'] = 'Viso užsakymų, gautų per laikotarpį, kurie yra laikomi patvirtintais.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Užsakymai';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_f15f2a2bf99d3dcad2cba1a2c615b9dc'] = 'Vidutinė krepšelio vertė yra metrinė vidutinio užsakymo per laikotarpį reikšmė. Ji apskaičiuojama dalinant pardavimus iš užsakymų.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_791d6355d34dfaf60d68ef04d1ee5767'] = 'Krepšelio vertė';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_4f631447981c5fa240006a5ae2c4b267'] = 'Viso apsilankymų skaičius per laikotarpį. Apsilankymas yra laikotarpis, per kurį lankytojas aktyviai dalyvauja Jūsų svetainėje.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_d7e637a6e9ff116de2fa89551240a94d'] = 'Apsilankymai';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_7a6e858f8c7c0b78fb4d43cefcb8c017'] = 'E-komercijos konversijos koeficientas yra vizitų, kurie pasibaigė patvirtintais užsakymais, procentas.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_e4c3da18c66c0147144767efeb59198f'] = 'Konversija';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_8dedc1b3ee3a92212fb5b5acad7f207f'] = 'Grynasis pelnas yra įmonės pelningumo matas atskaičius visas e-komercijos išlaidas.  Jūs galite pateikti šias išlaidas paspaudę konfigūracijos ikoną dešinėje aukščiau.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_43d729c7b81bfa5fc10e756660d877d1'] = 'Pelnas';


return $_MODULE;
