<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockbanner}prestashop>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Reklaminio skydelio blokas';
$_MODULE['<{blockbanner}prestashop>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Rodo reklaminį skydelį parduotuvės viršuje.';
$_MODULE['<{blockbanner}prestashop>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'Klaida įkeliant failą.';
$_MODULE['<{blockbanner}prestashop>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Nustatymai atnaujinti.';
$_MODULE['<{blockbanner}prestashop>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Nustatymai';
$_MODULE['<{blockbanner}prestashop>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Reklaminio skydelio paveiksliukas';
$_MODULE['<{blockbanner}prestashop>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Įkelkite paveiksliuką reklaminiam skydeliui. Jeigu naudojate numatytąją temą rekomenduojami matmenys yra 1170 x 65 px.';
$_MODULE['<{blockbanner}prestashop>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Reklaminio skydelio nuoroda';
$_MODULE['<{blockbanner}prestashop>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Įveskite nuorodą, kuri yra susijusi su reklaminiu skydeliu. Paspaudus paveiksliuką atsidarys nurodytas puslapis. Jeigu laukelį paliksite tuščią bus atidaromas pirmas puslapis.';
$_MODULE['<{blockbanner}prestashop>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Reklaminio skydelio aprašymas';
$_MODULE['<{blockbanner}prestashop>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Prašome įvesti reklaminiam skydeliui trumpą tačiau reikšmingą aprašymą.';
$_MODULE['<{blockbanner}prestashop>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{blockbanner}prestashop>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Pasirinkite failą';


return $_MODULE;
