<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{newsletter}prestashop>newsletter_ffb7e666a70151215b4c55c6268d7d72'] = 'Naujienlaiškiai';
$_MODULE['<{newsletter}prestashop>newsletter_804a924e464fd21ed92f820224c4091d'] = 'Generuoja .CSV bylą masiniam siuntimui';
$_MODULE['<{newsletter}prestashop>newsletter_c3987e4cac14a8456515f0d200da04ee'] = 'Visos šalys';
$_MODULE['<{newsletter}prestashop>newsletter_fa01fd956e87307bce4c90a0de9b0437'] = 'Kliento šalis';
$_MODULE['<{newsletter}prestashop>newsletter_7599b57d77ef1608b2f6da579794cc5b'] = 'Filtruoti klientus pagal šalis.';
$_MODULE['<{newsletter}prestashop>newsletter_2198f293f5e1e95dddeff819fbca0975'] = 'Užsisakę naujienlaiškį';
$_MODULE['<{newsletter}prestashop>newsletter_99006a61d48499231e1be92241cf772a'] = 'Filtruoti prenumeratorius.';
$_MODULE['<{newsletter}prestashop>newsletter_7e3a51a56ddd2846e21c33f05e0aea6f'] = 'Visi klientai';
$_MODULE['<{newsletter}prestashop>newsletter_39f7a3e2b56e9bfd753ba6325533a127'] = 'Prenumeratoriai';
$_MODULE['<{newsletter}prestashop>newsletter_011d8c5d94f729f013963d856cd78745'] = 'Neprenumeratoriai';
$_MODULE['<{newsletter}prestashop>newsletter_6395c19dc5a1cef9ca125b9736358dc7'] = 'Pasirinkti - prenumeratoriai';
$_MODULE['<{newsletter}prestashop>newsletter_3136b84457870341f29f741f7a07d325'] = 'Filtruoti pasirinkusius naujienlaiškio prenumeratą.';
$_MODULE['<{newsletter}prestashop>newsletter_82e5e0bc0f9c776c98253d569c111c0f'] = 'Su šiuo filtru nerasta jokių pirkėjų!';
$_MODULE['<{newsletter}prestashop>newsletter_644ecc2486a059ca16b001a77909bf40'] = '.CSV failas sėkmingai išeksportuotas: rasti %d klientai.';
$_MODULE['<{newsletter}prestashop>newsletter_48e3d5f66961b621c78f709afcd7d437'] = 'Atsisiųsti failą';
$_MODULE['<{newsletter}prestashop>newsletter_dca37b874cf34bd5ebcf1c2fdc59a8b4'] = 'ĮSPĖJIMAS: Jei atidarysite šį .csv failą su Excel programa, pasirinkite UTF-8 koduotę, kitu atveju matysite įvairius simbolius.';
$_MODULE['<{newsletter}prestashop>newsletter_b40866b115d74009183e06fc86b5c014'] = 'Klaida: Limituotos rašymo teisės';
$_MODULE['<{newsletter}prestashop>newsletter_81573e0ea79138f02fd2cee94786d7e9'] = 'Klaida: negalima rašyti';
$_MODULE['<{newsletter}prestashop>newsletter_73059f9530a1a37563150df4dea4bb70'] = 'Visi prenumeratoriai';
$_MODULE['<{newsletter}prestashop>newsletter_a307579714b75082f3f8734971b125cd'] = 'Prenumeratoriai su paskyromis';
$_MODULE['<{newsletter}prestashop>newsletter_d0da5609e4aebc5d532de97511a5a34a'] = 'Prenumeratoriai be paskyrų';
$_MODULE['<{newsletter}prestashop>newsletter_4713ef5f2d6fc1e8f088c850e696a04b'] = 'Eksportuoti klientus';
$_MODULE['<{newsletter}prestashop>newsletter_dbb392a2dc9b38722e69f6032faea73e'] = 'Eksportuoti .CSV bylą';


return $_MODULE;
