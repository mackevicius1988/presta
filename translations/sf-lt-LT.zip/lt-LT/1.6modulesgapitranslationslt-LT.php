<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{gapi}prestashop>gapi_69ee9bf9cf3d83a8468278c44959caf0'] = 'Google Analytics sąsaja (API)';
$_MODULE['<{gapi}prestashop>gapi_0851f7a0844553fa1168718de0f87262'] = 'Jums neleidžiama atidaryti išorinių URL';
$_MODULE['<{gapi}prestashop>gapi_6401593f1412a6b385c8e645d1f056ac'] = 'cURL neįjungtas';
$_MODULE['<{gapi}prestashop>gapi_f8b94463fa8b5591e5edbbb8021e8038'] = 'OpenSSL neįjungtas';
$_MODULE['<{gapi}prestashop>gapi_6e4c3e76dd29876e6d33ce8c89e5fc5f'] = 'Google serveris nepasiekiamas (patikrinkite savo ugniasienę)';
$_MODULE['<{gapi}prestashop>gapi_a1ed99ed6aaac91d7c3b127f032abf2d'] = 'Šiuo metu jūsų parduotuvė veikia lokaliame serveryje. Jei norite naudotis pilnomis galimybėmis, jūs turite įkelti savo parduotuvė į tikrą serverį.';
$_MODULE['<{gapi}prestashop>gapi_0237f944f5335bf28424f65ea896c22e'] = 'Atkreipkite dėmesį, kad Google Analitkos API veiks tik tada, kai:';
$_MODULE['<{gapi}prestashop>gapi_cc45f699445b43bb53e2519f013fba91'] = 'instaliuotas ir sukonfigūruotas "Google Analitika" modulis';
$_MODULE['<{gapi}prestashop>gapi_2d79f37dac5a9b0a1188bf50ed241c85'] = 'arba kai Google Analiktos skriptas jau įterptas jūsų parduotuvėje.';
$_MODULE['<{gapi}prestashop>gapi_2ccf68a6aec8eda73156a7ef54b03351'] = 'Kurią Google Analytics API versiją norite naudoti?';
$_MODULE['<{gapi}prestashop>gapi_0caf30452ef28d761ae80a407b64bd9b'] = 'v1.3: lengva konfigūruoti, tačiau pasenusi ir mažiau saugi';
$_MODULE['<{gapi}prestashop>gapi_949617ff3314c7cf2d88d356a953bd67'] = 'v3.0 su OAuth 2.0: naujausia ir galingiausia versija';
$_MODULE['<{gapi}prestashop>gapi_f1f4f41c5cab767032db832ec7bd5b64'] = 'Išsaugoti ir konfigūruoti';
$_MODULE['<{gapi}prestashop>gapi_00e9b476102174b72bce85f57ef4f251'] = 'Vakar jūsų parduotuvėje apsilankė %d žmonės(-ių) ir atliko %d puslapio peržiūrių.';
$_MODULE['<{gapi}prestashop>gapi_ac994aa3de9d2d547a386a0a05aaa4f9'] = 'Nueikite į https://code.google.com/apis/console ir paspauskite mygtuką "Sukurti projektą..." ( "Create project...")';
$_MODULE['<{gapi}prestashop>gapi_8bc5a7586c07901e92c09835eb4bf999'] = 'Skirtuke "APIs & AUTH > APIs", perjunkite prie Analitikos API';
$_MODULE['<{gapi}prestashop>gapi_cc33e14eed388f17b70ffdc1cf135e03'] = 'Jūsų gali paprašyti sutikti su Google API ir Analitkos API paslaugų teikimo sąlygomis';
$_MODULE['<{gapi}prestashop>gapi_6489ed26701b74c0fb139a3368804121'] = 'Jūs turėtumėte matyti kažką panašaus į';
$_MODULE['<{gapi}prestashop>gapi_ac868e51ad8cfbbe457407b4ed3a94ab'] = 'Skirtuke "APIs & AUTH > Credemtials" spauskite pirmą raudoną mygtuką "Sukurti naują kliento ID"';
$_MODULE['<{gapi}prestashop>gapi_d8334c85c0164bbdb0b24db654e6b611'] = 'Palikite pasirinkimą "web aplikacija" ir užpildykite "Autorizuoti JavaScript šaltiniai" lauką "%s" ir "%s" ir tada "Autorizuotas peradresavimo URI" lauką su "%s" ir "%s".';
$_MODULE['<{gapi}prestashop>gapi_4a7ee36b0b566be651113d36e6d87a86'] = 'Tuomet patvirtinkite spausdami "Sukurti kliento ID" mygtuką';
$_MODULE['<{gapi}prestashop>gapi_6e1e99918b40cf3f46166fae1e642b73'] = 'Dabar jūs turėtumėte matyti tokį puslapį. Nukopijuokite/įklijuokite "kliento ID" ir "klietno paslaptį" į žemiau esančia formą';
$_MODULE['<{gapi}prestashop>gapi_265c32931719280339cf19d733fea744'] = 'Toliau jums reikės Analitikos profilio ID, kurį jūs norite sujungti. Jei norite surasti savo profilio ID, prisijunkite prie Analitko skydelio, tuomet pažiūrėkite į puslapio URL. Jūsų profilio ID yra skaičius, kuris seka po raidės "p", taip, kaip pademonstruota nuotraukoje (raudonai)';
$_MODULE['<{gapi}prestashop>gapi_b18cb8e83113953f96bbe47bd90ab69c'] = 'Google Analytics sąsaja (API) v3.0 ';
$_MODULE['<{gapi}prestashop>gapi_76525f0f34b48475e5ca33f71d296f3b'] = 'Kliento ID';
$_MODULE['<{gapi}prestashop>gapi_734082edf44417dd19cc65943aa65c36'] = 'Kliento slaptasis raktas';
$_MODULE['<{gapi}prestashop>gapi_cce99c598cfdb9773ab041d54c3d973a'] = 'Profilis';
$_MODULE['<{gapi}prestashop>gapi_b1a026d322c634ca9e88525070e012fd'] = 'Išsaugoti ir autentifikuoti';
$_MODULE['<{gapi}prestashop>gapi_d4e6d6c42bf3eb807b8778255a4ce415'] = 'Identifikavimas nepavyko';
$_MODULE['<{gapi}prestashop>gapi_a670b4cdb42644e4b46fa857d3f73d9e'] = 'Google Analytics sąsaja (API) v1.3';
$_MODULE['<{gapi}prestashop>gapi_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'El.paštas';
$_MODULE['<{gapi}prestashop>gapi_dc647eb65e6711e155375218212b3964'] = 'Slaptažodis';
$_MODULE['<{gapi}prestashop>gapi_970a710b7344f8639b6a86d1f081b660'] = 'Jūs galite surasti savo profilio ID adreso laukelyje, kurį naudojate pasiekti savo Analytics raportui.';
$_MODULE['<{gapi}prestashop>gapi_e33d3b3409f8a0fcc326596c918c4961'] = 'SENOJE Google Analitkos versijoje, profilio ID yra "id" parametras URL (ieškokite "&id=xxxxxxxx"):';
$_MODULE['<{gapi}prestashop>gapi_c78fedea48082c7a437773e31b418f96'] = 'NAUJOJE Google Analitkos versijoje, profilio ID yra "p" parametras URL gale:';


return $_MODULE;
