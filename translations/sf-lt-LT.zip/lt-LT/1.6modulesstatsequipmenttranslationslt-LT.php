<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsequipment}prestashop>statsequipment_247270d410e2b9de01814b82111becda'] = 'Naršyklės ir operacinės sistemos';
$_MODULE['<{statsequipment}prestashop>statsequipment_2876718a648dea03aaafd4b5a63b1efe'] = 'Prideda skirtuką į statistikos skydelį, kuriame yra diagrama apie naršykles ir operacinių sistemų naudojimą.';
$_MODULE['<{statsequipment}prestashop>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Vedlys';
$_MODULE['<{statsequipment}prestashop>statsequipment_854c8e126f839cc861cde822b641230e'] = 'Įsitikinkite, kad Jūsų svetainė yra prieinama visiems žmonėms, kiek įmanoma';
$_MODULE['<{statsequipment}prestashop>statsequipment_0d5f13106dec10bb8a9301541052278c'] = 'Valdant svetainę yra svarbu sekti, kokią programinę įrangą naudoja lankytojai, kad būtumėte įsitikinę, kad svetainė rodo tą patį kelią kiekvienam.  PrestaShop buvo sukurta taip, kad būtų suderinama su naujausiomis tinklo naršyklėmis ir kompiuterių operacinėmis sistemomis (OS). Tačiau, kadangi Jūs galite pridėti papildomų funkcijų į savo svetainę ar net pakeisti pagrindinį PrestaShop kodą, šie papildymai gali būti neprieinami kiekvienam. Štai todėl yra gera idėja sekti kiekvienos programinės įrangos vartotojų procentą prieš pridedant ar kažką keičiant svetainėje, ko pasekoje būtų limituotas vartotojų, turinčių prieigą, skaičius.';
$_MODULE['<{statsequipment}prestashop>statsequipment_11db1362a88c5e3e74c8f699c14d6798'] = 'Nurodo kokias naršykles naudoja klientai/lankytojai.';
$_MODULE['<{statsequipment}prestashop>statsequipment_998e4c5c80f27dec552e99dfed34889a'] = 'CSV eksportas';
$_MODULE['<{statsequipment}prestashop>statsequipment_90c58bfe4872fc9ca7bf6a181c3e5edd'] = 'Nurodo kokias operacines sistemas naudoja klientai/lankytojai.';
$_MODULE['<{statsequipment}prestashop>statsequipment_bb38096ab39160dc20d44f3ea6b44507'] = 'Papildiniai (plug-ins)';
$_MODULE['<{statsequipment}prestashop>statsequipment_9ffafc9e090c8e1c06f928ef2817efd6'] = 'Naršyklių naudojimas';
$_MODULE['<{statsequipment}prestashop>statsequipment_0241b7aaaa5f76afd585bb6cdae314d1'] = 'Operacinių sistemų naudojimas';


return $_MODULE;
