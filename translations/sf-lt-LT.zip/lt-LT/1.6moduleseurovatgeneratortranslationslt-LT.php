<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{eurovatgenerator}prestashop>eurovatgenerator_267e605d64e4f9568839936222896911'] = 'Europinis PVM generatorius';
$_MODULE['<{eurovatgenerator}prestashop>eurovatgenerator_d30c038f173012c8bdbed1be880e05a0'] = 'Suderinkite savo prekes su naujomis europinio PVM taisyklėmis virtualioms prekėms.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_a73ab413109c43dd31f191a7d310e1ef'] = 'Europos PVM virtualioms prekėms';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_c2ef886abacc6606f222e8a12eeac91c'] = 'Šis modulis padeda jums lengvai sukurti reikalingus europinius mokesčius, kad Jūsų parduotuvė atitikų su naujomis virtualių prekių PVM taisyklėmis.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_47178f09d58b5d5c42576914ede0a423'] = 'Kai tai atliksite, jums reikės atnaujinti savo prekių katalogą pridedant šią europinę mokesčių taisyklę reikalingoms virtualioms prekėms.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_d234cb6833556b58cf492990ae9d704a'] = 'PVM tarifas šalims';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_0f9f2ade08049f7b9300a6ef34949ed4'] = 'Kiekvienai valstybei nurodykite, ar normalus PVM tarifas jau egzistuoja jūsų parduotuvėje. Jei ne, jis bus sukurtas automatiškai.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_29ed28e68b5c3365164aa2e0ccbe57bf'] = 'PVM jau egzistuoja mano parduotuvėje';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_b0fa79d5e3f6e671af3a8150f86ef60c'] = 'PVM neegzistuoja - jis bus sukurtas';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{eurovatgenerator}prestashop>configure_a73ab413109c43dd31f191a7d310e1ef'] = 'Europos PVM virtualioms prekėms';
$_MODULE['<{eurovatgenerator}prestashop>configure_c2ef886abacc6606f222e8a12eeac91c'] = 'Šis modulis padeda jums lengvai sukurti reikalingus europinius mokesčius, kad Jūsų parduotuvė atitikų su naujomis virtualių prekių PVM taisyklėmis.';
$_MODULE['<{eurovatgenerator}prestashop>configure_47178f09d58b5d5c42576914ede0a423'] = 'Kai tai atliksite, jums reikės atnaujinti savo prekių katalogą pridedant šią europinę mokesčių taisyklę reikalingoms virtualioms prekėms.';
$_MODULE['<{eurovatgenerator}prestashop>configure_d234cb6833556b58cf492990ae9d704a'] = 'PVM tarifas šalims';
$_MODULE['<{eurovatgenerator}prestashop>configure_0f9f2ade08049f7b9300a6ef34949ed4'] = 'Kiekvienai valstybei nurodykite, ar normalus PVM tarifas jau egzistuoja jūsų parduotuvėje. Jei ne, jis bus sukurtas automatiškai.';
$_MODULE['<{eurovatgenerator}prestashop>configure_29ed28e68b5c3365164aa2e0ccbe57bf'] = 'PVM jau egzistuoja mano parduotuvėje';
$_MODULE['<{eurovatgenerator}prestashop>configure_b0fa79d5e3f6e671af3a8150f86ef60c'] = 'PVM neegzistuoja - jis bus sukurtas';
$_MODULE['<{eurovatgenerator}prestashop>configure_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_7915b6921acab12d7737ea1810379b67'] = 'Visi mokesčiai sukurti. Nauja mokesčių taisyklė "Europinis PVM virtualioms prekėms" jau prieinamas.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_540fca2a5a01d285cd7509b98646cb14'] = 'Ką turėčiau daryti dabar?';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_892faeb6b5c1a83d8a8fa51562129449'] = 'Visi mokesčiai buvo sukurti ir yra prieinami per naują mokesčių taisyklę "Europinis PVM virtualioms prekėms".';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_e745e205828c0cddc2616ac37d06f35c'] = 'Dabar jūs turite priskirti šią naują mokesčių taisyklę virtualioms prekėms, kurios šis mokestis galioja.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_2ef23860578d16db7a13ba8131362bba'] = 'Taip pat galite saugiai ištrinti šį modulį.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_05da7f6548358c48a37680f8c8845811'] = 'Eiti į katalogą';
$_MODULE['<{eurovatgenerator}prestashop>done_7915b6921acab12d7737ea1810379b67'] = 'Visi mokesčiai sukurti. Nauja mokesčių taisyklė "Europinis PVM virtualioms prekėms" jau prieinamas.';
$_MODULE['<{eurovatgenerator}prestashop>done_540fca2a5a01d285cd7509b98646cb14'] = 'Ką turėčiau daryti dabar?';
$_MODULE['<{eurovatgenerator}prestashop>done_892faeb6b5c1a83d8a8fa51562129449'] = 'Visi mokesčiai buvo sukurti ir yra prieinami per naują mokesčių taisyklę "Europinis PVM virtualioms prekėms".';
$_MODULE['<{eurovatgenerator}prestashop>done_e745e205828c0cddc2616ac37d06f35c'] = 'Dabar jūs turite priskirti šią naują mokesčių taisyklę virtualioms prekėms, kurios šis mokestis galioja.';
$_MODULE['<{eurovatgenerator}prestashop>done_2ef23860578d16db7a13ba8131362bba'] = 'Taip pat galite saugiai ištrinti šį modulį.';
$_MODULE['<{eurovatgenerator}prestashop>done_05da7f6548358c48a37680f8c8845811'] = 'Eiti į katalogą';


return $_MODULE;
