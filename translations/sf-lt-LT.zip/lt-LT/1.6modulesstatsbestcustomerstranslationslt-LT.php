<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_4f29d8c727dcf2022ac241cb96c31083'] = 'Įrašų nėra';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_f5c493141bb4b2508c5938fd9353291a'] = 'Rodoma %1$s iš %2$s';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_77587239bf4c54ea493c7033e1dbf636'] = 'Pavardė';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_bc910f8bdf70f29374f496f05be0330c'] = 'Vardas';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'El.paštas';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_d7e637a6e9ff116de2fa89551240a94d'] = 'Apsilankymai';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_ec1ee973b8947391f8f014c76ac7379f'] = 'Patvirtinti užsakymai:';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_1ff1b62d08d1195f073c6adac00f1894'] = 'Išleista pinigų';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_8b83489bd116cb60e2f348e9c63cd7f6'] = 'Geriausi pirkėjai';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_9a1643c70b51526dd35d546ef8e17b87'] = 'Prideda geriausių pirkėjų sąrašą į statistikos skydelį.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_6602bbeb2956c035fb4cb5e844a4861b'] = 'Vedlys';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_cb21e843b037359d0fb5b793fccf964f'] = 'Skatinti kliento lojalumą';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_c01d21a09f02b8e661114db60a0f60d4'] = 'Išlaikyti esamą klientą gali būti pelningiau nei įgyti naują. Tai yra viena iš daugelio priežasčių, kodėl būtina ugdyti klientų lojalumą.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_197bad7ad08abfd1dc45ab92f96f155d'] = 'Word of mouth is also a means to of getting new, satisfied clients; a dissatisfied one won\'t attract new clients.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_bf0d87b5aa8d331563ee61f2ac82069d'] = 'Tam, kad pasiekti šį tikslą reikia:';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_397a5e109a5897ee7d699050cbc93347'] = 'Tikslinės operacijos: komerciniai apdovanojimai (personalizuoti specialūs pasiūlymai, siūlomos paslaugos ar servisai), ne komerciniai apdovanojimai (pirmenybinis užsakymo ar prekės apdorojimas).';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_4bc24eed56e0ba89fc3ab4e094d18d8a'] = 'Tvariosios operacijos: lojalumo taškai arba kortelės, kurios ne tik padeda bendrauti pardavėjui ir klientui, bet taip pat suteikia privalumų klientams (asmeniniai pasiūlymai, nuolaidos).';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_2f408c42912e3afe23a0e4adcbe34b96'] = 'Šios operacijos paskatins klientus pirkti prekes ir dažniau aplankyti Jūsų parduotuvę.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_998e4c5c80f27dec552e99dfed34889a'] = 'CSV eksportas';


return $_MODULE;
