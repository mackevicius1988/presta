<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_1056d03db619b016d8fc6b60d08ef488'] = 'Prekės mokėjimo logotipų blokas';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_88fd6d994459806f2dcb8999ac03c76e'] = 'Atvaizduoja galimų mokėjimo sistemų logotipus prekės puslapyje.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_126b21ce46c39d12c24058791a236777'] = 'Klaidingas paveiksliukas';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_df7859ac16e724c9b1fba0a364503d72'] = 'Klaida įkeliant failą.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_f4f70727dc34561dfde1a3c529b6205c'] = 'Nustatymai';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_223795d3a336ef80c5b6a070ae4e0d2a'] = 'Bloko antraštė';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_c7dd01cfb61ff8c984c0aff44f6540e3'] = 'Jūs galite pasirinkti, ar pridėti antraštę virš logotipo.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_89ca5c48bbc6b7a648a5c1996767484c'] = 'Bloko paveiksliukas';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_9ce38727cff004a058021a6c7351a74a'] = 'Paveiksliuko nuoroda';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_826eeee52fe142372c3a2bc195eff911'] = 'Galite įkelti paveiksliuką naudodamiesi aukščiau esančia forma, arba nurodyti jį naudojant "Paveiksliuko nuoroda" parinktį.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';


return $_MODULE;
