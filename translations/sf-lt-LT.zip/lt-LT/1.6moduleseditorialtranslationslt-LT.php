<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{editorial}prestashop>editorial_a46dcd3561c3feeb53903dfc0f796a35'] = 'Pagrindinio puslapio redaktorius';
$_MODULE['<{editorial}prestashop>editorial_48b5a6f8c5a4e81cd8eb07678a981649'] = 'Teksto redagavimo modulis jūsų pagrindiniam puslapiui.';
$_MODULE['<{editorial}prestashop>editorial_5db205c79efd29b0e4f52d0c1ff45d20'] = 'Išsaugoti';
$_MODULE['<{editorial}prestashop>editorial_0245625ee10f9c6c0ed7f50eb1838856'] = 'Pagrindinis pavadinimas';
$_MODULE['<{editorial}prestashop>editorial_4fb7f07fcf38a6401743822ade34e782'] = 'Rodomas jūsų pagrindinio puslapio viršuje';
$_MODULE['<{editorial}prestashop>editorial_e1f46be647e598f00eeb0ab62561d695'] = 'Paantraštė';
$_MODULE['<{editorial}prestashop>editorial_bf75f228011d1443c4ea7aca23c3cff2'] = 'Prisistatymo tekstas';
$_MODULE['<{editorial}prestashop>editorial_617f7661941abbf06f773fcb10031c7a'] = 'Pavyzdžiui, paaiškinkite savo misiją, atkreipkite dėmesį naujus produktus ar aprašykite nesenus įvykius.';
$_MODULE['<{editorial}prestashop>editorial_78587f196180054fcb797d40f4a86f10'] = 'Pagrindinio puslapio logotipas';
$_MODULE['<{editorial}prestashop>editorial_28d74ee805e3a162047d8f917b74dcb3'] = 'Pagrindinio puslapio logotipo nuorodą';
$_MODULE['<{editorial}prestashop>editorial_98039e8f2a0d93fc0fff503f9166f59b'] = 'Pagrindinio puslapio paantraštė';
$_MODULE['<{editorial}prestashop>editorial_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{editorial}prestashop>editorial_2563cfff94f1447b53116f3089940125'] = 'Šio veiksmo atlikti negalima';
$_MODULE['<{editorial}prestashop>editorial_5526efd7014a00a73115bcf90883d968'] = 'Bandant įkelti paveiksliuką įvyko klaida.';
$_MODULE['<{editorial}prestashop>editorial_8dd2f915acf4ec98006d11c9a4b0945b'] = 'Nustatymai sėkmingai atnaujinti.';


return $_MODULE;
