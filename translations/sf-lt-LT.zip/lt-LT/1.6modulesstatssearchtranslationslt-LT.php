<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statssearch}prestashop>statssearch_8c3c245232744602822902b97e65d6f9'] = 'Paieška parduotuvėje';
$_MODULE['<{statssearch}prestashop>statssearch_39ea81e520d21ea8e5b8265a177c07e0'] = 'Prideda skirtuką į statistikos skydelį, kuriame rodomi raktiniai žodžiai, kuriais ieškojo Jūsų parduotuvės lankytojai.';
$_MODULE['<{statssearch}prestashop>statssearch_867343577fa1f33caa632a19543bd252'] = 'Raktažodžiai';
$_MODULE['<{statssearch}prestashop>statssearch_e52e6aa1a43a0187e44f048f658db5f9'] = 'Pasirodymai';
$_MODULE['<{statssearch}prestashop>statssearch_fd69c5cf902969e6fb71d043085ddee6'] = 'Rezultatai';
$_MODULE['<{statssearch}prestashop>statssearch_998e4c5c80f27dec552e99dfed34889a'] = 'CSV eksportas';
$_MODULE['<{statssearch}prestashop>statssearch_710af2afb2786d5f79b2c9bd8a746b8b'] = 'Negalima rasti jokių raktinių žodžių, ieškotų daugiau nei vieną kartą.';
$_MODULE['<{statssearch}prestashop>statssearch_e15832aa200f342e8f4ab580b43a72a8'] = 'Pirmieji 10 raktažodžių';
$_MODULE['<{statssearch}prestashop>statssearch_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Kiti';


return $_MODULE;
