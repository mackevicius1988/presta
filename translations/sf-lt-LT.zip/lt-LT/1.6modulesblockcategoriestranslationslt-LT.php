<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcategories}prestashop>blockcategories_8f0ed7c57fca428f7e3f8e64d2f00918'] = 'Kategorijų blokas';
$_MODULE['<{blockcategories}prestashop>blockcategories_15a6f5841d9e4d7e62bec3319b4b7036'] = 'Prideda bloką kategorijų rodymui.';
$_MODULE['<{blockcategories}prestashop>blockcategories_23e0d4ecc25de9b2777fdaca3e2f3193'] = 'Maksimalus gylis: klaidingas skaičius.';
$_MODULE['<{blockcategories}prestashop>blockcategories_0cf328636f0d607ac24a5c435866b94b'] = 'Dinaminis HTML: neteisingas pasirinkimas.';
$_MODULE['<{blockcategories}prestashop>blockcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Nustatymai';
$_MODULE['<{blockcategories}prestashop>blockcategories_1379a6b19242372c1f23cc9adedfcdd6'] = 'Pagrindinė kategorija';
$_MODULE['<{blockcategories}prestashop>blockcategories_c6d333d07d30f7b4c31a94bbd510bf88'] = 'Pasirinkite, kuri kategorija bus rodoma bloke. Dabartinė kategorija yra ta, kurią lankytojai šiuo metu naršo.';
$_MODULE['<{blockcategories}prestashop>blockcategories_89b278a71f2be5f620307502326587a0'] = 'Pagrindinė kategorija';
$_MODULE['<{blockcategories}prestashop>blockcategories_62381fc27e62649a16182a616de3f7ea'] = 'Dabartinė kategorija';
$_MODULE['<{blockcategories}prestashop>blockcategories_52b68aaa602d202c340d9e4e9157f276'] = 'Pagrindinė kategorija';
$_MODULE['<{blockcategories}prestashop>blockcategories_f225631c1a6f71e99cc779f6bbf06dd4'] = 'Dabartinė kategorija, jei ji neturi subkategorijų, tokiu atveju naudojama dabartinės kategorijos aukštesnioji kategorija';
$_MODULE['<{blockcategories}prestashop>blockcategories_19561e33450d1d3dfe6af08df5710dd0'] = 'Didžiausias gylis';
$_MODULE['<{blockcategories}prestashop>blockcategories_584d4e251b6f778eda9cfc2fc756b0b0'] = 'Nustatomas didžiausias leistinas kategorijos gylis rodomas bloke (0 = neribojamas).';
$_MODULE['<{blockcategories}prestashop>blockcategories_971fd8cc345d8bd9f92e9f7d88fdf20c'] = 'Dinaminis';
$_MODULE['<{blockcategories}prestashop>blockcategories_c10efcaa2a8ff4eedaa3538fff78eb53'] = 'Aktyvuoti dinaminį (animuotą) rėžimą sub-kategorijų atvaizdavimui.';
$_MODULE['<{blockcategories}prestashop>blockcategories_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Įjungta';
$_MODULE['<{blockcategories}prestashop>blockcategories_b9f5c797ebbf55adccdd8539a65a0241'] = 'Išjungta';
$_MODULE['<{blockcategories}prestashop>blockcategories_6b46ae48421828d9973deec5fa9aa0c3'] = 'Rikiuoti';
$_MODULE['<{blockcategories}prestashop>blockcategories_54e4f98fb34254a6678f0795476811ed'] = 'Pagal pavadinimą';
$_MODULE['<{blockcategories}prestashop>blockcategories_883f0bd41a4fcee55680446ce7bec0d9'] = 'Pagal poziciją';
$_MODULE['<{blockcategories}prestashop>blockcategories_06f1ac65b0a6a548339a38b348e64d79'] = 'Rikiavimo tvarka';
$_MODULE['<{blockcategories}prestashop>blockcategories_e3cf5ac19407b1a62c6fccaff675a53b'] = 'Mažėjantis';
$_MODULE['<{blockcategories}prestashop>blockcategories_cf3fb1ff52ea1eed3347ac5401ee7f0c'] = 'Didėjantis';
$_MODULE['<{blockcategories}prestashop>blockcategories_5f73e737cedf8f4ccf880473a7823005'] = 'Stulpelių skaičius puslapio apačioje';
$_MODULE['<{blockcategories}prestashop>blockcategories_c9cc8cce247e49bae79f15173ce97354'] = 'Išsaugoti';
$_MODULE['<{blockcategories}prestashop>blockcategories_footer_af1b98adf7f686b84cd0b443e022b7a0'] = 'Kategorijos';
$_MODULE['<{blockcategories}prestashop>blockcategories_af1b98adf7f686b84cd0b443e022b7a0'] = 'Kategorijos';
$_MODULE['<{blockcategories}prestashop>blockcategories_admin_63239117f39d923b2e407620fc1fa5b5'] = 'Numatytoje temoje šie paveiksliukai bus rodomi viršutiniame horizontaliame meniu; bet tik tuo atveju, jei kategorija yra viena iš pirmo lygmens (daugiau informacijos modulyje "Viršutinis horizontalus meniu").';
$_MODULE['<{blockcategories}prestashop>blockcategories_admin_eea317348d82718d49f9a79189dc0f93'] = 'Meniu miniatiūros';
$_MODULE['<{blockcategories}prestashop>blockcategories_admin_5bc1667deb2b522c0cac00de5f15ffbc'] = 'Rekomenduojami matmenys (numatytajai temai): %1spx x %2spx';


return $_MODULE;
